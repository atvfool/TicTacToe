' -------------------------------------------------------------------------
'   Module: modDatabaseUtilities
'   Author: Patrick Callahan
'   Abstract: Some general purpose database utilities.
'
'   Revision        Owner   Changes:
'1  2001/04/17      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
'  Options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------

Public Module modDatabaseUtilities


    ' -------------------------------------------------------------------------
    '  Global constants
    ' -------------------------------------------------------------------------


    ' -------------------------------------------------------------------------
    '  Global variables
    ' -------------------------------------------------------------------------
    ' SQL Server Connection string with integrated login v1   
    'Private m_strDatabaseConnectionString As String = "Provider=SQLOLEDB;" & _
    '                                                  "Server=(Local);" & _
    '                                                  "Database=dbTeamsAndPlayers;" & _
    '                                                  "Trusted_Connection=True;"

    ' SQL Server Connection string with integrated login v2
    Private m_strDatabaseConnectionString As String = "Provider=SQLOLEDB;" & _
                                                      "Server=(Local);" & _
                                                      "Database=dbTeamsAndPlayers;" & _
                                                      "Integrated Security=SSPI;"

    ' SQL Express Connection string                             
    'Private m_strDatabaseConnectionString As String = "Provider=SQLOLEDB;" & _
    '                                                  "Server=(Local)\SQLEXPRESS;" & _
    '                                                  "Database=dbTeamsAndPlayers;" & _
    '                                                  "User ID=sa;" & _
    '                                                  "Password=;"

    ' Access 2000 / Windows XP Connection string                             
    'Private m_strDatabaseConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
    '                                                "Data Source=" & Application.StartupPath & "..\..\..\Database\TeamsAndPlayers1.mdb;" & _
    '                                                "User ID=Admin;" & _
    '                                                "Password=;"

    ' Access 2007 / Windows 7 Connection string                             
    'Private m_strDatabaseConnectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;" & _
    '                                                "Data Source=" & Application.StartupPath & "..\..\..\Database\TeamsAndPlayers1.mdb;" & _
    '                                                "User ID=Admin;" & _
    '                                                "Password=;"

    ' In a 2-Tier app we connect once and hold the connection open
    Private m_conAdministrator As OleDb.OleDbConnection
    Private m_daTeamsAndPlayers As OleDb.OleDbDataAdapter
    Private m_cmdSelect As OleDb.OleDbCommand
    Private m_cbSQLCommands As OleDb.OleDbCommandBuilder            ' Auto builds DML (Select, Insert, Update, Delete) commands


#Region "Open/Close Connection"

    ' -------------------------------------------------------------------------
    ' Name: OpenDatabaseConnection
    ' Abstract: Open a connection to the database.
    '           In a 2-Tier (client server) application we connect once in FMain
    '           and hold the connection open until FMain closes
    '
    '           ********** READ ME **********
    '
    '           For MS Access on Windows Vista/7 you must set the target CPU to "x86"
    '           under "Project/Properties/Compiler/Advanced Compil Options (button at bottom)/Target CPU"
    ' -------------------------------------------------------------------------
    Public Function OpenDatabaseConnection() As Boolean

        Dim blnResult As Boolean = False

        Try

            ' Open a connection to the database
            m_conAdministrator = New OleDb.OleDbConnection
            m_conAdministrator.ConnectionString = m_strDatabaseConnectionString
            m_conAdministrator.Open()

            ' Set connection for Command object
            m_cmdSelect = New OleDb.OleDbCommand
            m_cmdSelect.Connection = m_conAdministrator

            ' Set the SQL Command for the data adapter
            m_daTeamsAndPlayers = New OleDb.OleDbDataAdapter
            m_daTeamsAndPlayers.SelectCommand = m_cmdSelect

            ' Set the command builder
            m_cbSQLCommands = New OleDb.OleDbCommandBuilder
            m_cbSQLCommands.DataAdapter = m_daTeamsAndPlayers

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

            MessageBox.Show("Unable to connect to the database!" & vbNewLine & _
                            "The application will now close." & vbNewLine & _
                            vbNewLine & _
                            "See modDatabaseUtilities.OpenDatabaseConnection for more details", _
                             "Database Connection Error", _
                             MessageBoxButtons.OK, _
                             MessageBoxIcon.Information)

        End Try

        Return blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: CloseDatabaseConnection
    ' Abstract: If the database connection is open then close it.  Release the
    '           memory.
    ' -------------------------------------------------------------------------
    Public Function CloseDatabaseConnection() As Boolean

        Dim blnResult As Boolean = False

        Try

            ' If the connection is open then close it
            If m_conAdministrator.State <> ConnectionState.Closed Then

                m_conAdministrator.Close()

            End If

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function

#End Region

#Region "Load Lists"

    ' -------------------------------------------------------------------------
    ' Name: LoadListBoxFromDatabase
    ' Abstract: Load a Listbox control from a table in the Database
    ' -------------------------------------------------------------------------
    Public Function LoadListBoxFromDatabase(ByVal strTable As String, _
                                            ByVal strPrimaryKey As String, _
                                            ByVal strNameColumn As String, _
                                            ByRef lstTarget As ListBox, _
                                   Optional ByVal strSortColumn As String = "", _
                                   Optional ByVal strCustomSQL As String = "") As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim dtSource As New DataTable()
            Dim clsItem As CListItem
            Dim intIndex As Integer
            Dim intID As Integer
            Dim strName As String

            ' Clear out the list
            lstTarget.Items.Clear()

            m_cmdSelect.CommandText = BuildSelectStatement(strTable, strPrimaryKey, _
                                                           strNameColumn, strSortColumn, _
                                                           strCustomSQL)

            ' Set SQL statemment
            m_daTeamsAndPlayers.SelectCommand = m_cmdSelect

            ' Retreive the all the records from select command and store in dataset provided
            m_daTeamsAndPlayers.Fill(dtSource)

            With dtSource

                ' Show changes all at once (MUCH faster).  
                lstTarget.BeginUpdate()

                ' Loop through all the records
                For intIndex = 0 To .Rows.Count - 1

                    ' Make a List Item  item to hold the information
                    intID = .Rows(intIndex).Item(0)     ' Primary Key
                    strName = .Rows(intIndex).Item(1)   ' Name Column
                    clsItem = New CListItem(intID, strName)

                    ' Add the item to the list
                    intIndex = lstTarget.Items.Add(clsItem)

                Next

            End With

            ' Show any changes
            lstTarget.EndUpdate()

            ' Select the first item in the list by default
            If lstTarget.Items.Count > 0 Then lstTarget.SelectedIndex = 0

            ' Clean up
            dtSource.Dispose()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: LoadComboBoxFromDatabase
    ' Abstract: Load a Combobox control from a table in the Database
    ' -------------------------------------------------------------------------
    Public Function LoadComboBoxFromDatabase(ByVal strTable As String, _
                                             ByVal strPrimaryKey As String, _
                                             ByVal strNameColumn As String, _
                                             ByRef cmbTarget As ComboBox, _
                                    Optional ByVal strSortColumn As String = "", _
                                    Optional ByVal strCustomSQL As String = "") As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim dtSource As New DataTable
            Dim clsItem As CListItem
            Dim intIndex As Integer
            Dim intID As Integer
            Dim strName As String

            ' Clear out the list
            cmbTarget.Items.Clear()

            m_cmdSelect.CommandText = BuildSelectStatement(strTable, strPrimaryKey, _
                                                           strNameColumn, strSortColumn, _
                                                           strCustomSQL)

            ' Set SQL statemment
            m_daTeamsAndPlayers.SelectCommand = m_cmdSelect

            ' Retreive the all the records
            m_daTeamsAndPlayers.Fill(dtSource)

            With dtSource

                ' Show changes all at once (MUCH faster).  
                cmbTarget.BeginUpdate()

                ' Loop through all the records
                For intIndex = 0 To .Rows.Count - 1

                    ' Make an Name/Value item to hold the information
                    intID = .Rows(intIndex).Item(0)     ' Primary Key
                    strName = .Rows(intIndex).Item(1)   ' Name Column
                    clsItem = New CListItem(intID, strName)

                    ' Add the item to the list
                    intIndex = cmbTarget.Items.Add(clsItem)

                Next

            End With

            ' Show any changes
            cmbTarget.EndUpdate()

            ' Select the first item in the list by default
            If cmbTarget.Items.Count > 0 Then cmbTarget.SelectedIndex = 0

            ' Clean up
            dtSource.Dispose()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: BuildSelectStatement
    ' Abstract: Build a select state for the table, ID and Name column.
    ' -------------------------------------------------------------------------
    Private Function BuildSelectStatement(ByVal strTable As String, _
                                          ByVal strPrimaryKey As String, _
                                          ByVal strNameColumn As String, _
                                          ByVal strSortColumn As String, _
                                          ByVal strCustomSQL As String) As String

        Dim strSelectStatement As String = ""

        Try

            ' Custom select statement?
            If strCustomSQL = "" Then

                ' No, so build one

                ' Sort by name column if nothing provided
                If strSortColumn = "" Then strSortColumn = strNameColumn

                ' Put it all together
                strSelectStatement = "SELECT " & _
                                        strPrimaryKey & ", " & strNameColumn & _
                                     " FROM " & _
                                        strTable & _
                                     " ORDER BY " & strSortColumn

            Else

                ' Yes, use it
                strSelectStatement = strCustomSQL

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return strSelectStatement

    End Function



    ' -------------------------------------------------------------------------
    ' Name: LoadListViewFromDatabase
    ' Abstract: Load a ListView control from a table in the Database.
    '           Save the ID in the tag property.
    '
    ' Sample Call:
    '   Dim astrNames() As String = { "strLastName", "strFirstName", "strPhoneNumber" }
    '   LoadListViewFromDatabase( "TCustomers", "intCustomerID", astrNames, lvwCustomers )
    '
    ' -------------------------------------------------------------------------
    Public Function LoadListViewFromDatabase(ByVal strTable As String, _
                                             ByVal strPrimaryKey As String, _
                                             ByVal astrNameColumns() As String, _
                                             ByRef lvwTarget As ListView, _
                                    Optional ByVal strSortColumn As String = "", _
                                    Optional ByVal strCustomSQL As String = "") As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim dtSource As New DataTable
            Dim lviNewItem As ListViewItem
            Dim intRowIndex As Integer
            Dim intColumnIndex As Integer

            ' Clear out the list
            lvwTarget.Items.Clear()

            m_cmdSelect.CommandText = BuildSelectStatement(strTable, strPrimaryKey, _
                                                           astrNameColumns, strSortColumn, _
                                                           strCustomSQL)

            ' Set SQL statemment
            m_daTeamsAndPlayers.SelectCommand = m_cmdSelect

            ' Retreive the all the records
            m_daTeamsAndPlayers.Fill(dtSource)

            With dtSource

                ' Show changes all at once (MUCH faster).  
                lvwTarget.BeginUpdate()

                ' Loop through all the records
                For intRowIndex = 0 To .Rows.Count - 1

                    ' Make an listview item to hold the information
                    lviNewItem = New ListViewItem()
                    lviNewItem.Tag = .Rows(intRowIndex).Item(0)     ' Primary Key
                    lviNewItem.Text = .Rows(intRowIndex).Item(1)    ' Name Column(1)

                    ' Add all the other columns
                    For intColumnIndex = 2 To .Rows(intRowIndex).ItemArray.Length - 1

                        ' One at a time
                        lviNewItem.SubItems.Add(.Rows(intRowIndex).Item(intColumnIndex))

                    Next

                    ' Add the item to the list
                    lvwTarget.Items.Add(lviNewItem)

                Next

            End With

            ' Show any changes
            lvwTarget.EndUpdate()

            ' Select the first item in the list by default
            If lvwTarget.Items.Count > 0 Then lvwTarget.Items(0).Selected = True

            ' Clean up
            dtSource.Dispose()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: BuildSelectStatement
    ' Abstract: Build a select state for the table, ID and Name column.
    ' -------------------------------------------------------------------------
    Private Function BuildSelectStatement(ByVal strTable As String, _
                                          ByVal strPrimaryKey As String, _
                                          ByVal astrNameColumns() As String, _
                                          ByVal strSortColumn As String, _
                                          ByVal strCustomSQL As String) As String

        Dim strSelectStatement As String = ""

        Try

            Dim intIndex As Integer = 0
            Dim strAllNameColumns As String = ""

            ' Custom select statement?
            If strCustomSQL = "" Then

                ' No, so build one

                ' Get all the name columns
                For intIndex = 0 To astrNameColumns.Length - 1

                    strAllNameColumns &= ", " & astrNameColumns(intIndex)

                Next

                ' Remove leading comma
                strAllNameColumns = strAllNameColumns.Substring(2)

                ' Sort by name column if nothing provided 
                If strSortColumn = "" Then strSortColumn = strAllNameColumns

                ' Put it all together
                strSelectStatement = "SELECT " & _
                                        strPrimaryKey & ", " & strAllNameColumns & _
                                     " FROM " & _
                                        strTable & _
                                     " ORDER BY " & strSortColumn

            Else

                ' Yes, use it
                strSelectStatement = strCustomSQL

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return strSelectStatement

    End Function


#End Region

#Region "Delete/GetNextHighest Record"

    ' -------------------------------------------------------------------------
    ' Name: DeleteRecordsFromTable
    ' Abstract: Delete all records from table that match the ID.
    ' -------------------------------------------------------------------------
    Public Function DeleteRecordsFromTable(ByVal intRecordID As Integer, _
                                           ByVal strPrimaryKey As String, _
                                           ByVal strTable As String, _
                                  Optional ByVal strCustomSQL As String = "") As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim intRowsAffected As Integer = 0

            ' Custom SQL?
            If strCustomSQL <> "" Then

                ' Yes, use it
                m_cmdSelect.CommandText = strCustomSQL

            Else

                ' No, build the SQL String
                m_cmdSelect.CommandText = "DELETE FROM " & strTable & _
                                          " WHERE " & strPrimaryKey & " = " & intRecordID

            End If

            ' Prepare the data adapter for the update
            m_daTeamsAndPlayers.DeleteCommand = m_cmdSelect

            ' Do it
            intRowsAffected = m_daTeamsAndPlayers.DeleteCommand.ExecuteNonQuery()

            ' Clean up (must do or we get concurrency violation if we add then delete)
            m_daTeamsAndPlayers.DeleteCommand = Nothing

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: GetNextHighestRecordID
    ' Abstract: Get the next highest ID from the table in the database
    '           Danger: Potential race condition.
    '           Why do we have this?  So we can see the mechanics of how
    '           everthing works.  
    ' -------------------------------------------------------------------------
    Public Function GetNextHighestRecordID(ByVal strPrimaryKey As String, _
                                           ByVal strTable As String, _
                                           ByRef intNextHighestRecordID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim drTable As OleDb.OleDbDataReader

            m_cmdSelect.CommandText = "SELECT MAX( " & strPrimaryKey & " ) AS intHighestRecordID " & _
                                      " FROM " & strTable

            ' Execute command
            drTable = m_cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drTable.Read()

            ' Null? (empty table)
            If drTable.IsDBNull(0) = True Then

                ' Yes, start at 1
                intNextHighestRecordID = 1

            Else
                ' Get the next highest ID
                intNextHighestRecordID = drTable.Item("intHighestRecordID") + 1

            End If

            ' Clean up
            drTable.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function

#End Region

#Region "Teams"

    ' ----------------------------------------------------------------------------------------------------
    ' ----------------------------------------------------------------------------------------------------
    '                                       Teams
    ' ----------------------------------------------------------------------------------------------------
    ' ----------------------------------------------------------------------------------------------------


    ' -------------------------------------------------------------------------
    ' Name: AddTeamToDatabase
    ' Abstract: How to add a record using a stored procedure that returns
    '           the record ID.  Use this for SQL Server.
    '
    '           Advantages:
    '           1) There is only one back and forth from the code to the database.
    '           2) Using a stored procedure takes much of the SQL out of our
    '              code and puts it in the database.
    '           3) Stored procedures are guaranteed to by syntactically correct
    '              once created (unless you are doing dynamic queries)
    '           4) Stored procedures are pre-compiled (after first run and then cached)
    '              so they execute as quickly as possible.
    '           5) Transactions in procedures are automatically rolled back
    '              if they encounter an error when called from
    '              an application.  This is good because we will never
    '              have an uncommited transaction.
    '           6) Once started the stored procedure is guaranteed to finish
    '              without any further input which is good because we will never
    '              have an uncommited transaction.
    ' -------------------------------------------------------------------------
    Public Function AddTeamToDatabase(ByRef udtTeam As udtTeamType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand
            Dim objDataReader As OleDb.OleDbDataReader

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspAddTeam", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strTeam", udtTeam.strTeam))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strMascot", udtTeam.strMascot))

            ' Execute the stored procedure
            objDataReader = objSQLCommand.ExecuteReader()

            ' Should be 1 and only 1 record returned
            objDataReader.Read()

            ' Get the new ID (could also use an output parameter)
            udtTeam.intTeamID = objDataReader.Item(0)

            ' Clean up
            objDataReader.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: GetTeamInformationFromDatabase
    ' Abstract: Get data for the specified team from the database
    ' -------------------------------------------------------------------------
    Public Function GetTeamInformationFromDatabase(ByRef udtTeam As udtTeamType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim dtTTeams As DataTable = New DataTable

            ' Build the select string
            m_cmdSelect.CommandText = "SELECT * FROM TTeams " & _
                                      " WHERE intTeamID = " & udtTeam.intTeamID

            ' Load the data set (using the select statement)
            m_daTeamsAndPlayers.SelectCommand = m_cmdSelect
            m_cbSQLCommands.RefreshSchema()                 ' Must refresh after changing select
            m_daTeamsAndPlayers.Fill(dtTTeams)

            ' Retrieve the team's information (should be 1 and only 1 row)
            With dtTTeams.Rows.Item(0)
                udtTeam.strTeam = .Item("strTeam")
                udtTeam.strMascot = .Item("strMascot")
            End With

            ' Clean up
            dtTTeams.Dispose()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: EditTeamInDatabase
    ' Abstract: Save the team to the database
    ' -------------------------------------------------------------------------
    Public Function EditTeamInDatabase(ByVal udtTeam As udtTeamType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspEditTeam", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intTeamID", udtTeam.intTeamID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strTeam", udtTeam.strTeam))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strMascot", udtTeam.strMascot))

            ' Execute the stored procedure
            objSQLCommand.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: DeleteTeamFromDatabase
    ' Abstract: Don't really delete.  Just mark as inactive.
    ' -------------------------------------------------------------------------
    Public Function DeleteTeamFromDatabase(ByVal intTeamID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            blnResult = SetTeamStatusInDatabase(intTeamID, enuTeamStatusType.Inactive)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: UndeleteTeamFromDatabase
    ' Abstract: Rise, I command you!  Rise!
    ' -------------------------------------------------------------------------
    Public Function UndeleteTeamFromDatabase(ByVal intTeamID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            blnResult = SetTeamStatusInDatabase(intTeamID, enuTeamStatusType.Active)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetTeamStatusInDatabase
    ' Abstract: Set the status to either active or inactive
    ' -------------------------------------------------------------------------
    Private Function SetTeamStatusInDatabase(ByVal intTeamID As Integer, ByVal enuTeamStatus As enuTeamStatusType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspSetTeamStatus", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intTeamID", intTeamID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intTeamStatusID", enuTeamStatus))

            ' Execute the stored procedure
            objSQLCommand.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



#End Region

#Region "Players"

    ' ----------------------------------------------------------------------------------------------------
    ' ----------------------------------------------------------------------------------------------------
    '                                       Players
    ' ----------------------------------------------------------------------------------------------------
    ' ----------------------------------------------------------------------------------------------------


    ' -------------------------------------------------------------------------
    ' Name: AddPlayerToDatabase
    ' Abstract: How to add a record using a stored procedure that returns
    '           the record ID.  Use this for SQL Server.
    '
    '           Advantages:
    '           1) There is only one back and forth from the code to the database.
    '           2) Using a stored procedure takes much of the SQL out of our
    '              code and puts it in the database.
    '           3) Stored procedures are guaranteed to by syntactically correct
    '              once created (unless you are doing dynamic queries)
    '           4) Stored procedures are pre-compiled (after first run and then cached)
    '              so they execute as quickly as possible.
    '           5) Transactions in procedures are automatically rolled back
    '              if they encounter an error when called from
    '              an application.  This is good because we will never
    '              have an uncommited transaction.
    '           6) Once started the stored procedure is guaranteed to finish
    '              without any further input which is good because we will never
    '              have an uncommited transaction.
    ' -------------------------------------------------------------------------
    Public Function AddPlayerToDatabase(ByRef udtPlayer As udtPlayerType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand
            Dim objDataReader As OleDb.OleDbDataReader

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspAddPlayer", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strFirstName", udtPlayer.strFirstName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strMiddleName", udtPlayer.strMiddleName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strLastName", udtPlayer.strLastName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strStreetAddress", udtPlayer.strStreetAddress))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strCity", udtPlayer.strCity))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intStateID", udtPlayer.intStateID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strZipCode", udtPlayer.strZipCode))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strHomePhoneNumber", udtPlayer.strHomePhoneNumber))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strEmergencyContactName", udtPlayer.strEmergencyContactName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strEmergencyContactPhoneNumber", udtPlayer.strEmergencyContactPhoneNumber))

            ' Execute the stored procedure
            objDataReader = objSQLCommand.ExecuteReader()

            ' Should be 1 and only 1 record returned
            objDataReader.Read()

            ' Get the new ID (could also use an output parameter)
            udtPlayer.intPlayerID = objDataReader.Item(0)

            ' Clean up
            objDataReader.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: GetPlayerInformationFromDatabase
    ' Abstract: Get data for the specified Player from the database
    ' -------------------------------------------------------------------------
    Public Function GetPlayerInformationFromDatabase(ByRef udtPlayer As udtPlayerType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim dtTPlayers As DataTable = New DataTable

            ' Build the select string
            m_cmdSelect.CommandText = "SELECT * FROM TPlayers " & _
                                      " WHERE intPlayerID = " & udtPlayer.intPlayerID

            ' Load the data set (using the select statement)
            m_daTeamsAndPlayers.SelectCommand = m_cmdSelect
            m_cbSQLCommands.RefreshSchema()                 ' Must refresh after changing select
            m_daTeamsAndPlayers.Fill(dtTPlayers)

            ' Retrieve the Player's information (should be 1 and only 1 row)
            With dtTPlayers.Rows.Item(0)
                udtPlayer.strFirstName = .Item("strFirstName")
                udtPlayer.strMiddleName = .Item("strMiddleName")
                udtPlayer.strLastName = .Item("strLastName")
                udtPlayer.strStreetAddress = .Item("strStreetAddress")
                udtPlayer.strCity = .Item("strCity")
                udtPlayer.intStateID = .Item("intStateID")
                udtPlayer.strZipCode = .Item("strZipCode")
                udtPlayer.strHomePhoneNumber = .Item("strHomePhoneNumber")
                udtPlayer.strEmergencyContactName = .Item("strEmergencyContactName")
                udtPlayer.strEmergencyContactPhoneNumber = .Item("strEmergencyContactPhoneNumber")
            End With

            ' Clean up
            dtTPlayers.Dispose()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: EditPlayerInDatabase
    ' Abstract: Save the player to the database
    ' -------------------------------------------------------------------------
    Public Function EditPlayerInDatabase(ByVal udtPlayer As udtPlayerType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspEditPlayer", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intPlayerID", udtPlayer.intPlayerID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strFirstName", udtPlayer.strFirstName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strMiddleName", udtPlayer.strMiddleName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strLastName", udtPlayer.strLastName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strStreetAddress", udtPlayer.strStreetAddress))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strCity", udtPlayer.strCity))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intStateID", udtPlayer.intStateID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strZipCode", udtPlayer.strZipCode))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strHomePhoneNumber", udtPlayer.strHomePhoneNumber))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strEmergencyContactName", udtPlayer.strEmergencyContactName))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@strEmergencyContactPhoneNumber", udtPlayer.strEmergencyContactPhoneNumber))

            ' Execute the stored procedure
            objSQLCommand.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: DeletePlayerFromDatabase
    ' Abstract: Don't really delete.  Just mark as inactive.
    ' -------------------------------------------------------------------------
    Public Function DeletePlayerFromDatabase(ByVal intPlayerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            blnResult = SetPlayerStatusInDatabase(intPlayerID, enuPlayerStatusType.Inactive)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: UndeletePlayerFromDatabase
    ' Abstract: Rise, I command you!  Rise!
    ' -------------------------------------------------------------------------
    Public Function UndeletePlayerFromDatabase(ByVal intPlayerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            blnResult = SetPlayerStatusInDatabase(intPlayerID, enuPlayerStatusType.Active)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetPlayerStatusInDatabase
    ' Abstract: Set the status to either active or inactive
    ' -------------------------------------------------------------------------
    Private Function SetPlayerStatusInDatabase(ByVal intPlayerID As Integer, ByVal enuPlayerStatus As enuPlayerStatusType) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspSetPlayerStatus", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intPlayerID", intPlayerID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intPlayerStatusID", enuPlayerStatus))

            ' Execute the stored procedure
            objSQLCommand.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function

#End Region

#Region "Team Players"


    ' ----------------------------------------------------------------------------------------------------
    ' ----------------------------------------------------------------------------------------------------
    '                                       Team Players
    ' ----------------------------------------------------------------------------------------------------
    ' ----------------------------------------------------------------------------------------------------


    ' -------------------------------------------------------------------------
    ' Name: LoadListWithPlayersFromDatabase
    ' Abstract: Load all the players on/not on the specified team.
    ' -------------------------------------------------------------------------
    Public Function LoadListWithPlayersFromDatabase(ByVal intTeamID As Integer, _
                                                    ByRef lstTarget As ListBox, _
                                                    ByVal blnPlayersOnTeam As Boolean) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected players?
            If blnPlayersOnTeam = True Then strNot = ""

            ' Build the Custom SQL Select statement
            ' We either want all the players on the team or all the players NOT on the team
            ' Players must be active
            strCustomSQL = "SELECT " & _
                           "    intPlayerID, strLastName + ', ' + strFirstName " & _
                           "FROM " & _
                           "    TPlayers " & _
                           "WHERE intPlayerID " & strNot & " IN " & _
                           "    ( SELECT intPlayerID " & _
                           "      FROM TTeamPlayers " & _
                           "      WHERE intTeamID = " & intTeamID & _
                           "    ) " & _
                           "    AND intPlayerStatusID = " & intPLAYER_STATUS_ACTIVE & _
                           "ORDER BY " & _
                           "    strLastName, strFirstName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: AddPlayerToTeamInDatabase
    ' Abstract: Add the player to the specified team
    ' -------------------------------------------------------------------------
    Function AddPlayerToTeamInDatabase(ByVal intTeamID As Integer, _
                                       ByVal intPlayerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspAddTeamPlayer", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intTeamID", intTeamID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intPlayerID", intPlayerID))

            ' Execute the stored procedure
            objSQLCommand.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: RemovePlayerFromTeamInDatabase
    ' Abstract: Remove the player from the specified team
    ' -------------------------------------------------------------------------
    Function RemovePlayerFromTeamInDatabase(ByVal intTeamID As Integer, _
                                            ByVal intPlayerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim objSQLCommand As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            objSQLCommand = New OleDb.OleDbCommand("uspDeleteTeamPlayer", m_conAdministrator)
            objSQLCommand.CommandType = CommandType.StoredProcedure

            ' Add parameters
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intTeamID", intTeamID))
            objSQLCommand.Parameters.Add(New OleDb.OleDbParameter("@intPlayerID", intPlayerID))

            ' Execute the stored procedure
            objSQLCommand.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function

#End Region

End Module
