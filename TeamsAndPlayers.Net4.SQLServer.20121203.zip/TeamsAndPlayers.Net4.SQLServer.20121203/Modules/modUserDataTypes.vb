' -------------------------------------------------------------------------
'   Module: modUserDataTypes
'   Author: Patrick Callahan
'   Abstract: User defined data types
'
'   Revision        Owner   Changes:
'1  2001/04/17      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
'  Options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------



Public Module modUserDataTypes

    ' Structures are like suitcases.  
    ' It's a lot easier to carry one suitcase instead of a whole bunch of loose items.
    ' Same with passing data to a procedure.  Instead of having 4+ variables just use
    ' a structure.

    ' Team
    Public Structure udtTeamType

        Dim intTeamID As Integer
        Dim strTeam As String
        Dim strMascot As String

    End Structure

    Public Enum enuTeamStatusType As Integer

        Active = 1
        Inactive = 2

    End Enum


    ' Player
    Public Structure udtPlayerType

        Dim intPlayerID As Integer
        Dim strFirstName As String
        Dim strMiddleName As String
        Dim strLastName As String
        Dim strStreetAddress As String
        Dim strCity As String
        Dim intStateID As Integer
        Dim strZipCode As String
        Dim strHomePhoneNumber As String
        Dim strEmergencyContactName As String
        Dim strEmergencyContactPhoneNumber As String
        Friend strState As Object

    End Structure

    Public Enum enuPlayerStatusType As Integer

        Active = 1
        Inactive = 2

    End Enum

End Module
