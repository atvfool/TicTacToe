' -------------------------------------------------------------------------
'   Module: modUtilities
'   Author: Patrick Callahan
'   Abstract: Some general purpose utilities.
'
'   Revision        Owner   Changes:
'1  2001/04/17      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
'  Options
' -------------------------------------------------------------------------
Option Explicit On

Imports System
Imports System.IO
Imports System.Windows.Forms
Imports System.Text.RegularExpressions

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Module modUtilities

    ' -------------------------------------------------------------------------
    '  Global constants
    ' -------------------------------------------------------------------------
    ' What log file should we use
    Private Const strLOG_FILE_EXTENSION As String = ".Log"

    ' -------------------------------------------------------------------------
    '  Global variables
    ' -------------------------------------------------------------------------
    Private m_strOldLogFilePath As String           ' Name of the last log file opened
    Private m_fsLogFile As FileStream = Nothing     ' File handle of the last log file opened


    ' -------------------------------------------------------------------------
    ' Name: SetBusyCursor
    ' Abstract: Enable/Disable the form and set the cursor to normal or busy.
    ' -------------------------------------------------------------------------
    Public Sub SetBusyCursor(ByRef frmForm As Form, ByVal blnBusy As Boolean)

        Try

            ' Busy?
            If blnBusy = True Then

                ' Yes
                frmForm.Cursor = Cursors.WaitCursor
                frmForm.Enabled = False

            Else

                ' No
                frmForm.Cursor = Cursors.Default
                frmForm.Enabled = True

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: TrimAllFormTextBoxes
    ' Abstract: Trim all the textboxes on the form
    ' -------------------------------------------------------------------------
    Public Sub TrimAllFormTextBoxes(ByRef frmForm As Form)

        Try

            Dim intIndex As Integer
            Dim txtCurrentControl As TextBox

            ' Loop through all the controls on the form
            For intIndex = 0 To frmForm.Controls.Count - 1

                ' If this is a text box then ...
                If TypeOf frmForm.Controls.Item(intIndex) Is TextBox Then

                    ' Trim the spaces
                    txtCurrentControl = frmForm.Controls.Item(intIndex)
                    txtCurrentControl.Text = txtCurrentControl.Text.Trim

                End If

            Next

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetVersion
    ' Abstract: Get the major, minor revision numbers. Format at M.m.
    ' -------------------------------------------------------------------------
    Public Function GetVersion() As String

        Dim strVersion As String = ""

        Try

            ' Major
            strVersion &= System.Reflection.Assembly.GetExecutingAssembly.GetName().Version.Major.ToString()

            ' Minor
            strVersion &= "." & System.Reflection.Assembly.GetExecutingAssembly.GetName().Version.Minor.ToString()

            ' or strVersion = Application.Version

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return strVersion

    End Function


    ' -------------------------------------------------------------------------
    ' Name: CheckForPreviousApplicationInstance
    ' Abstract: Check to see if a previous instance exists( true )
    ' -------------------------------------------------------------------------
    Public Function CheckForPreviousApplicationInstance() As Boolean

        Dim blnPreviousInstance As Boolean = False

        Try

            Dim strCurrentProcessName As String = Diagnostics.Process.GetCurrentProcess.ProcessName

            ' Does a previous version exist?
            If UBound(Diagnostics.Process.GetProcessesByName(strCurrentProcessName)) > 0 Then

                ' Yes
                blnPreviousInstance = True

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnPreviousInstance

    End Function



    ' -------------------------------------------------------------------------
    ' Name: Wait
    ' Abstract: Wait a few seconds
    ' -------------------------------------------------------------------------
    Public Sub Wait(ByVal intMilliSeconds As Integer)

        Try

            Dim dtmWaitUntil As Date

            ' Maximum of 10 second wait
            If intMilliSeconds > 10000 Then intMilliSeconds = 10000

            ' Get the current time
            dtmWaitUntil = Now.AddMilliseconds(intMilliSeconds)

            ' Wait 
            Do While Now < dtmWaitUntil

                Application.DoEvents()

            Loop

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: HighlightNextItemInList
    ' Abstract: Highlight the next closest item in the list
    ' -------------------------------------------------------------------------
    Public Sub HighlightNextItemInList(ByRef lstTarget As ListBox, ByVal intIndex As Integer)

        Try

            Dim intItemCount As Integer

            ' Are there any items in the list( might have deleted the last one )?
            intItemCount = lstTarget.Items.Count
            If intItemCount > 0 Then

                ' Yes

                ' Did we delete the last item?
                If intIndex >= intItemCount Then

                    ' Yes, move the index to the new last item
                    intIndex = intItemCount - 1

                End If

                ' Select next closest item
                lstTarget.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: HighlightNextItemInList
    ' Abstract: Highlight the next closest item in the list
    ' -------------------------------------------------------------------------
    Public Sub HighlightNextItemInList(ByRef lvwTarget As ListView, ByVal intSelectIndex As Integer)

        Try

            Dim intItemCount As Integer
            Dim intIndex As Integer

            ' Loop through currently selected items
            For intIndex = lvwTarget.SelectedItems.Count - 1 To 0 Step -1

                ' and clear them
                lvwTarget.SelectedItems.Item(intIndex).Selected = False

            Next

            ' Are there any items in the list( might have deleted the last one )?
            intItemCount = lvwTarget.Items.Count
            If intItemCount > 0 Then

                ' Yes

                ' Did we delete the last item?
                If intSelectIndex >= intItemCount Then

                    ' Yes, move the index to the new last item
                    intSelectIndex = intItemCount - 1

                End If

                ' Select next closest item
                lvwTarget.Items(intSelectIndex).Selected = True

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: GetSelectedListItemID
    ' Abstract: Get the ID for the currently selected list item.  Default to 0.
    ' -------------------------------------------------------------------------
    Public Function GetSelectedListItemID(ByVal lstSource As ListBox) As Integer

        Dim intSelectedItemID As Integer = 0

        Try

            Dim clsSelectedItem As CListItem

            ' Is an item selected?
            If lstSource.SelectedIndex >= 0 Then

                ' Yes, get the ID from the item
                clsSelectedItem = lstSource.Items.Item(lstSource.SelectedIndex)
                intSelectedItemID = clsSelectedItem.GetID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return intSelectedItemID

    End Function



    ' -------------------------------------------------------------------------
    ' Name: GetSelectedListItemID
    ' Abstract: Get the ID for the currently selected list item.  Default to 0.
    ' -------------------------------------------------------------------------
    Public Function GetSelectedListItemID(ByVal lvwSource As ListView) As Integer

        Dim intSelectedItemID As Integer = 0

        Try

            Dim lviSelectedItem As ListViewItem

            ' Is an item selected?
            If lvwSource.SelectedItems.Count > 0 Then

                ' Yes, get the ID from the tag property
                lviSelectedItem = lvwSource.SelectedItems.Item(0)
                intSelectedItemID = Val(lviSelectedItem.Tag)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return intSelectedItemID

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SelectItemInListFromID
    ' Abstract: Find the item with the matching ID and select it
    ' -------------------------------------------------------------------------
    Public Sub SelectItemInListFromID(ByRef lstTarget As ListBox, ByVal intSelectID As Integer)

        Try

            Dim intIndex As Integer
            Dim clsCurrentItem As CListItem

            ' Loop through all the items in the target list
            For intIndex = 0 To lstTarget.Items.Count - 1

                ' Current item
                clsCurrentItem = lstTarget.Items(intIndex)

                ' Is this the ID we want?
                If clsCurrentItem.GetID = intSelectID Then

                    ' Yes, select it
                    lstTarget.SelectedIndex = intIndex

                    ' Stop searching
                    Exit For

                End If

            Next

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: SelectItemInListFromID
    ' Abstract: Find the item with the matching ID and select it
    ' -------------------------------------------------------------------------
    Public Sub SelectItemInListFromID(ByRef cmbTarget As ComboBox, ByVal intSelectID As Integer)

        Try

            Dim intIndex As Integer
            Dim clsCurrentItem As CListItem

            ' Loop through all the items in the target list
            For intIndex = 0 To cmbTarget.Items.Count - 1

                ' Current item
                clsCurrentItem = cmbTarget.Items(intIndex)

                ' Is this the ID we want?
                If clsCurrentItem.GetID = intSelectID Then

                    ' Yes, select it
                    cmbTarget.SelectedIndex = intIndex

                    ' Stop searching
                    Exit For

                End If

            Next

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: SelectItemInListFromID
    ' Abstract: Find the item with the matching ID and select it
    ' -------------------------------------------------------------------------
    Public Sub SelectItemInListFromID(ByRef lvwTarget As ListView, ByVal intSelectID As Integer)

        Try

            Dim intIndex As Integer
            Dim lviCurrentItem As ListViewItem

            ' Loop through currently selected items
            For intIndex = lvwTarget.SelectedItems.Count - 1 To 0 Step -1

                ' and clear them
                lvwTarget.SelectedItems.Item(intIndex).Selected = False

            Next

            ' Loop through all the items in the target list
            For intIndex = 0 To lvwTarget.Items.Count - 1

                ' Current item
                lviCurrentItem = lvwTarget.Items(intIndex)

                ' Is this the ID we want?
                If Val(lviCurrentItem.Tag) = intSelectID Then

                    ' Yes, select it
                    lviCurrentItem.Selected = True

                    ' Stop searching
                    Exit For

                End If

            Next

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


#Region "Error Log"


    ' -------------------------------------------------------------------------
    ' Name: WriteLog
    ' Abstract: Overload withd blnDisplay set to true
    ' -------------------------------------------------------------------------
    Public Sub WriteLog(ByVal excErrorToLog As Exception, Optional ByVal blnDisplayWarning As Boolean = True)

        Try

            WriteLog(excErrorToLog.ToString(), blnDisplayWarning)

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: WriteLog
    ' Abstract: Write a message to the error log.
    ' -------------------------------------------------------------------------
    Public Sub WriteLog(ByVal strMessageToLog As String, Optional ByVal blnDisplayWarning As Boolean = True)

        Try

            Dim fsLogFile As FileStream = Nothing
            Dim encConvertToByteArray As New System.Text.UTF8Encoding

            ' Warn the user?
            If blnDisplayWarning = True Then

                ' Yes( ProductName is set in AssemblyInfo )
                MessageBox.Show(strMessageToLog, Application.ProductName, _
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)

            End If

            ' Append a date/time stamp
            strMessageToLog = (DateTime.Now).ToString("yyyy/MM/dd HH:mm:ss") & " - " & strMessageToLog & vbNewLine & _
                              vbNewLine

            ' Get a free file handle
            fsLogFile = GetLogFile()

            ' Is the file OK?
            If Not fsLogFile Is Nothing Then

                ' Yes, Log it
                fsLogFile.Write(encConvertToByteArray.GetBytes(strMessageToLog), 0, strMessageToLog.Length)

                ' Flush the buffer so we can immediately see results in file.  Very important.
                ' Otherwise we have to wait for flush which might be when application closes
                ' or we get another error.  Waiting for the application to close may not be
                ' a good idea if the application is in a production environment (e.g. a web app
                ' running on a remote server)
                fsLogFile.Flush()

            End If

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: DeleteOldFiles
    ' Abstract: Delete any files older than 10 days.
    ' -------------------------------------------------------------------------
    Private Sub DeleteOldFiles()

        Try

            Dim strLogFilePath As String = ""
            Dim dirLogDirectory As DirectoryInfo = Nothing
            Dim dtmFileCreated As DateTime = Now
            Dim intDaysOld As Integer = 0

            ' Path
            strLogFilePath = Application.StartupPath & "\Log\"

            ' Look for any files
            dirLogDirectory = New DirectoryInfo(strLogFilePath)

            ' Are there any?
            For Each finLogFile As FileInfo In dirLogDirectory.GetFiles("*" & strLOG_FILE_EXTENSION)

                ' When was the file created?
                dtmFileCreated = finLogFile.CreationTime

                ' How old is the file?
                intDaysOld = (dtmFileCreated.Subtract(DateTime.Now)).Days

                ' Is the file older than 10 days?
                If intDaysOld > 10 Then

                    ' Yes.  Delete it.
                    finLogFile.Delete()

                End If

            Next

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetLogFile
    ' Abstract: Open the log file for writing.  Use today's date as part of
    '           the file name.  Each day a new log file will be created.
    '           Makes debug easier.
    '           Use a filestream object so we can specify file read share
    '           during the open call.
    ' -------------------------------------------------------------------------
    Private Function GetLogFile() As FileStream

        Try
            Dim strToday As String = (DateTime.Now).ToString("yyyyMMdd")
            Dim strLogFilePath As String = ""

            ' Log everything in a log directory off of the current application directory
            strLogFilePath = Application.StartupPath & "\Log\" & strToday & strLOG_FILE_EXTENSION

            ' Is this a new day?
            If m_strOldLogFilePath <> strLogFilePath Then

                ' Save the log file name
                m_strOldLogFilePath = strLogFilePath

                ' Does the log directory exist?
                If Directory.Exists(Application.StartupPath & "\Log") = False Then

                    ' No, so create it
                    Directory.CreateDirectory(Application.StartupPath & "\Log")

                End If

                ' Close old log file( if there is one )
                If Not m_fsLogFile Is Nothing Then m_fsLogFile.Close()

                ' Delete old log files
                DeleteOldFiles()

                ' Does the file exist?
                If File.Exists(strLogFilePath) = False Then

                    ' No, create with shared read access so it can be read while application has it open
                    m_fsLogFile = New FileStream(strLogFilePath, FileMode.Create, FileAccess.Write, FileShare.Read)

                Else

                    ' Yes, append with shared read access so it can be read while application has it open
                    m_fsLogFile = New FileStream(strLogFilePath, FileMode.Append, FileAccess.Write, FileShare.Read)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

        ' Return result
        Return m_fsLogFile

    End Function

#End Region

End Module
