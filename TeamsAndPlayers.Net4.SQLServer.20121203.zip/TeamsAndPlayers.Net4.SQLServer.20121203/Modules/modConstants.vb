﻿' -------------------------------------------------------------------------
'   Module: modConstants
'   Author: Patrick Callahan
'   Abstract: Constants - usually matched to PK value in the database
'
'   Revision        Owner   Changes:
'1  2012/09/19      P.C.    Created.
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
'  Options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------



Public Module modConstants

    Public Const intPLAYER_STATUS_ACTIVE As Integer = 1
    Public Const intPLAYER_STATUS_INACTIVE As Integer = 2

End Module
