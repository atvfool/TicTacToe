' -------------------------------------------------------------------------
'   Form: FManagePlayers
'   Purpose: Allow the user to manage( add/edit/delete ) a Player
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FManagePlayersV1

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------



    ' -------------------------------------------------------------------------
    ' Name: FManagePlayers_Load
    ' Abstract: Do any initialization
    ' -------------------------------------------------------------------------
    Private Sub FManagePlayers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            ' This may take a while
            Me.Show()

            LoadPlayerList()

            ' Set the focus
            lstPlayers.Focus()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadPlayerList
    ' Abstract: Load the Player list
    ' -------------------------------------------------------------------------
    Private Sub LoadPlayerList()

        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActivePlayers"

            Else

                strSourceTable = "VInactivePlayers"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            LoadListBoxFromDatabase(strSourceTable, _
                                    "intPlayerID", _
                                    "strPlayer", _
                                    lstPlayers)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Player
    ' -------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        Try

            AddPlayer()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: AddPlayer
    ' Abstract: Add a Player
    ' -------------------------------------------------------------------------
    Private Sub AddPlayer()

        Try

            Dim frmAddPlayer As FAddPlayer
            Dim clsPlayer As CListItem
            Dim intListIndex As Integer

            ' Create form
            frmAddPlayer = New FAddPlayer

            ' Show it
            frmAddPlayer.ShowDialog(Me)

            ' Was the Add successful?
            If frmAddPlayer.GetResult() = True Then

                ' Get the new Player information
                clsPlayer = frmAddPlayer.GetNewPlayerInformation()

                ' Add the item to the list and select it
                intListIndex = lstPlayers.Items.Add(clsPlayer)
                lstPlayers.SelectedIndex = intListIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: lstPlayers_DblClick
    ' Abstract: Same as clicking edit
    ' -------------------------------------------------------------------------
    Private Sub lstPlayers_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstPlayers.DoubleClick

        Try

            ' Same as clicking edit
            EditPlayer()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the currently selected Player
    ' -------------------------------------------------------------------------
    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click

        Try

            EditPlayer()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: EditPlayer
    ' Abstract: Edit the currently selected Player
    ' -------------------------------------------------------------------------
    Private Sub EditPlayer()

        Try

            Dim frmEditPlayer As FEditPlayer

            Dim intSelectedPlayerID As Integer
            Dim clsPlayer As CListItem
            Dim intListIndex As Integer

            ' Get the selected Player ID
            intSelectedPlayerID = GetSelectedListItemID(lstPlayers)

            ' Is a Player selected?
            If intSelectedPlayerID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, create form
                frmEditPlayer = New FEditPlayer

                ' Yes, set the form values
                frmEditPlayer.SetFormValues(intSelectedPlayerID)

                ' Show it
                frmEditPlayer.ShowDialog(Me)

                ' Was the Add successful?
                If frmEditPlayer.GetResult() = True Then

                    ' Get the new Player information
                    clsPlayer = frmEditPlayer.GetNewPlayerInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstPlayers.Items.RemoveAt(lstPlayers.SelectedIndex)
                    intListIndex = lstPlayers.Items.Add(clsPlayer)
                    lstPlayers.SelectedIndex = intListIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the currently selected Player.
    ' -------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click

        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeletePlayer()

            Else

                ' No, undelete
                UndeletePlayer()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: DeletePlayer
    ' Abstract: Delete the currently selected Player.
    ' -------------------------------------------------------------------------
    Private Sub DeletePlayer()

        Try

            Dim intSelectedPlayerID As Integer
            Dim strSelectedPlayerName As String
            Dim intSelectedPlayerIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Get the selected Player ID
            intSelectedPlayerID = GetSelectedListItemID(lstPlayers)

            ' Is a Player selected?
            If intSelectedPlayerID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Player name and list index
                strSelectedPlayerName = lstPlayers.Items.Item(lstPlayers.SelectedIndex).GetName
                intSelectedPlayerIndex = lstPlayers.SelectedIndex

                ' Yes, confirm they want to delete
                drConfirm = MessageBox.Show("Are you sure?", "Delete Player: " & strSelectedPlayerName, _
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Player and all the Player players assignments
                    blnResult = DeletePlayerFromDatabase(intSelectedPlayerID)

                    ' Was the delete successful?
                    If blnResult = True Then

                        ' Yes, remove the Player from the list
                        lstPlayers.Items.RemoveAt(intSelectedPlayerIndex)

                        ' Select the next Player in the list
                        HighlightNextItemInList(lstPlayers, intSelectedPlayerIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: UndeletePlayer
    ' Abstract: Undelete the currently selected Player.
    ' -------------------------------------------------------------------------
    Private Sub UndeletePlayer()

        Try

            Dim intSelectedPlayerID As Integer
            Dim intSelectedPlayerIndex As Integer
            Dim blnResult As Boolean

            ' Get the selected Player ID
            intSelectedPlayerID = GetSelectedListItemID(lstPlayers)

            ' Is a Player selected?
            If intSelectedPlayerID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the list index
                intSelectedPlayerIndex = lstPlayers.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, delete the Player and all the Player players assignments
                blnResult = UndeletePlayerFromDatabase(intSelectedPlayerID)

                ' Was the delete successful?
                If blnResult = True Then

                    ' Yes, remove the Player from the list
                    lstPlayers.Items.RemoveAt(intSelectedPlayerIndex)

                    ' Select the next Player in the list
                    HighlightNextItemInList(lstPlayers, intSelectedPlayerIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active and inactive teams
    ' -------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowDeleted.CheckedChanged

        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            LoadPlayerList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form
    ' -------------------------------------------------------------------------
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Try

            ' Goodbye cruel world
            Me.Hide()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

End Class
