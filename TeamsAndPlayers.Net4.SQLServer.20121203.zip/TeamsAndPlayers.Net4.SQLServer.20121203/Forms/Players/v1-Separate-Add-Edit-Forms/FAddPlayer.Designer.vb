<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAddPlayer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtEmergencyContactPhoneNumber = New System.Windows.Forms.TextBox()
        Me.txtEmergencyContactName = New System.Windows.Forms.TextBox()
        Me.txtHomePhoneNumber = New System.Windows.Forms.TextBox()
        Me.txtZipCode = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtStreetAddress = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblEmergencyContactPhoneNumber = New System.Windows.Forms.Label()
        Me.lblEmergencyContactName = New System.Windows.Forms.Label()
        Me.lblHomePhoneNumber = New System.Windows.Forms.Label()
        Me.lblZipCode = New System.Windows.Forms.Label()
        Me.lblState = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblStreetAddress = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblRequiredField = New System.Windows.Forms.Label()
        Me.lblMiddleName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.cmbState = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'txtEmergencyContactPhoneNumber
        '
        Me.txtEmergencyContactPhoneNumber.Location = New System.Drawing.Point(152, 302)
        Me.txtEmergencyContactPhoneNumber.MaxLength = 50
        Me.txtEmergencyContactPhoneNumber.Name = "txtEmergencyContactPhoneNumber"
        Me.txtEmergencyContactPhoneNumber.Size = New System.Drawing.Size(152, 20)
        Me.txtEmergencyContactPhoneNumber.TabIndex = 39
        '
        'txtEmergencyContactName
        '
        Me.txtEmergencyContactName.Location = New System.Drawing.Point(152, 270)
        Me.txtEmergencyContactName.MaxLength = 50
        Me.txtEmergencyContactName.Name = "txtEmergencyContactName"
        Me.txtEmergencyContactName.Size = New System.Drawing.Size(152, 20)
        Me.txtEmergencyContactName.TabIndex = 38
        '
        'txtHomePhoneNumber
        '
        Me.txtHomePhoneNumber.Location = New System.Drawing.Point(152, 238)
        Me.txtHomePhoneNumber.MaxLength = 50
        Me.txtHomePhoneNumber.Name = "txtHomePhoneNumber"
        Me.txtHomePhoneNumber.Size = New System.Drawing.Size(152, 20)
        Me.txtHomePhoneNumber.TabIndex = 37
        '
        'txtZipCode
        '
        Me.txtZipCode.Location = New System.Drawing.Point(152, 206)
        Me.txtZipCode.MaxLength = 50
        Me.txtZipCode.Name = "txtZipCode"
        Me.txtZipCode.Size = New System.Drawing.Size(152, 20)
        Me.txtZipCode.TabIndex = 36
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(152, 142)
        Me.txtCity.MaxLength = 50
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(152, 20)
        Me.txtCity.TabIndex = 34
        '
        'txtStreetAddress
        '
        Me.txtStreetAddress.Location = New System.Drawing.Point(152, 110)
        Me.txtStreetAddress.MaxLength = 50
        Me.txtStreetAddress.Name = "txtStreetAddress"
        Me.txtStreetAddress.Size = New System.Drawing.Size(152, 20)
        Me.txtStreetAddress.TabIndex = 33
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(152, 78)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(152, 20)
        Me.txtLastName.TabIndex = 32
        '
        'txtMiddleName
        '
        Me.txtMiddleName.Location = New System.Drawing.Point(152, 46)
        Me.txtMiddleName.MaxLength = 50
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(152, 20)
        Me.txtMiddleName.TabIndex = 31
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(152, 14)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(152, 20)
        Me.txtFirstName.TabIndex = 30
        '
        'lblEmergencyContactPhoneNumber
        '
        Me.lblEmergencyContactPhoneNumber.Location = New System.Drawing.Point(16, 305)
        Me.lblEmergencyContactPhoneNumber.Name = "lblEmergencyContactPhoneNumber"
        Me.lblEmergencyContactPhoneNumber.Size = New System.Drawing.Size(144, 21)
        Me.lblEmergencyContactPhoneNumber.TabIndex = 52
        Me.lblEmergencyContactPhoneNumber.Text = "Emergency Contact Phone:"
        '
        'lblEmergencyContactName
        '
        Me.lblEmergencyContactName.Location = New System.Drawing.Point(16, 273)
        Me.lblEmergencyContactName.Name = "lblEmergencyContactName"
        Me.lblEmergencyContactName.Size = New System.Drawing.Size(144, 16)
        Me.lblEmergencyContactName.TabIndex = 51
        Me.lblEmergencyContactName.Text = "Emergency ContactName:"
        '
        'lblHomePhoneNumber
        '
        Me.lblHomePhoneNumber.Location = New System.Drawing.Point(16, 241)
        Me.lblHomePhoneNumber.Name = "lblHomePhoneNumber"
        Me.lblHomePhoneNumber.Size = New System.Drawing.Size(144, 16)
        Me.lblHomePhoneNumber.TabIndex = 50
        Me.lblHomePhoneNumber.Text = "Home Phone Number:*"
        '
        'lblZipCode
        '
        Me.lblZipCode.Location = New System.Drawing.Point(16, 209)
        Me.lblZipCode.Name = "lblZipCode"
        Me.lblZipCode.Size = New System.Drawing.Size(144, 16)
        Me.lblZipCode.TabIndex = 49
        Me.lblZipCode.Text = "Zip Code:"
        '
        'lblState
        '
        Me.lblState.Location = New System.Drawing.Point(16, 177)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(144, 16)
        Me.lblState.TabIndex = 48
        Me.lblState.Text = "State:"
        '
        'lblCity
        '
        Me.lblCity.Location = New System.Drawing.Point(16, 145)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(144, 16)
        Me.lblCity.TabIndex = 47
        Me.lblCity.Text = "City:"
        '
        'lblStreetAddress
        '
        Me.lblStreetAddress.Location = New System.Drawing.Point(16, 113)
        Me.lblStreetAddress.Name = "lblStreetAddress"
        Me.lblStreetAddress.Size = New System.Drawing.Size(144, 16)
        Me.lblStreetAddress.TabIndex = 46
        Me.lblStreetAddress.Text = "Street:"
        '
        'lblLastName
        '
        Me.lblLastName.Location = New System.Drawing.Point(16, 81)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(144, 16)
        Me.lblLastName.TabIndex = 45
        Me.lblLastName.Text = "Last Name:*"
        '
        'lblRequiredField
        '
        Me.lblRequiredField.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequiredField.Location = New System.Drawing.Point(152, 329)
        Me.lblRequiredField.Name = "lblRequiredField"
        Me.lblRequiredField.Size = New System.Drawing.Size(120, 16)
        Me.lblRequiredField.TabIndex = 44
        Me.lblRequiredField.Text = "* Required Field"
        '
        'lblMiddleName
        '
        Me.lblMiddleName.Location = New System.Drawing.Point(16, 49)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(144, 16)
        Me.lblMiddleName.TabIndex = 42
        Me.lblMiddleName.Text = "Middle Name:"
        '
        'lblFirstName
        '
        Me.lblFirstName.Location = New System.Drawing.Point(16, 17)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(144, 16)
        Me.lblFirstName.TabIndex = 40
        Me.lblFirstName.Text = "First Name:*"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(172, 355)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(88, 26)
        Me.btnCancel.TabIndex = 54
        Me.btnCancel.Text = "&Cancel"
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(60, 355)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(88, 26)
        Me.btnOK.TabIndex = 53
        Me.btnOK.Text = "&OK"
        '
        'cmbState
        '
        Me.cmbState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbState.FormattingEnabled = True
        Me.cmbState.Location = New System.Drawing.Point(152, 174)
        Me.cmbState.Name = "cmbState"
        Me.cmbState.Size = New System.Drawing.Size(152, 21)
        Me.cmbState.TabIndex = 35
        '
        'FAddPlayer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(320, 397)
        Me.Controls.Add(Me.cmbState)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtEmergencyContactPhoneNumber)
        Me.Controls.Add(Me.txtEmergencyContactName)
        Me.Controls.Add(Me.txtHomePhoneNumber)
        Me.Controls.Add(Me.txtZipCode)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtStreetAddress)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtMiddleName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblEmergencyContactPhoneNumber)
        Me.Controls.Add(Me.lblEmergencyContactName)
        Me.Controls.Add(Me.lblHomePhoneNumber)
        Me.Controls.Add(Me.lblZipCode)
        Me.Controls.Add(Me.lblState)
        Me.Controls.Add(Me.lblCity)
        Me.Controls.Add(Me.lblStreetAddress)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblRequiredField)
        Me.Controls.Add(Me.lblMiddleName)
        Me.Controls.Add(Me.lblFirstName)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAddPlayer"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Add Player"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtEmergencyContactPhoneNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtEmergencyContactName As System.Windows.Forms.TextBox
    Friend WithEvents txtHomePhoneNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtZipCode As System.Windows.Forms.TextBox
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtStreetAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtMiddleName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents lblEmergencyContactPhoneNumber As System.Windows.Forms.Label
    Friend WithEvents lblEmergencyContactName As System.Windows.Forms.Label
    Friend WithEvents lblHomePhoneNumber As System.Windows.Forms.Label
    Friend WithEvents lblZipCode As System.Windows.Forms.Label
    Friend WithEvents lblState As System.Windows.Forms.Label
    Friend WithEvents lblCity As System.Windows.Forms.Label
    Friend WithEvents lblStreetAddress As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblRequiredField As System.Windows.Forms.Label
    Friend WithEvents lblMiddleName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents cmbState As System.Windows.Forms.ComboBox
End Class
