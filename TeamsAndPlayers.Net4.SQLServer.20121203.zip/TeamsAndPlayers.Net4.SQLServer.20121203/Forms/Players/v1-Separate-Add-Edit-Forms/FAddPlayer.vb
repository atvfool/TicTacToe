' -------------------------------------------------------------------------
'   Form: FAddPlayer
'   Purpose: Allow the user to add/edit a Player
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FAddPlayer

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------
    Private f_blnLoaded As Boolean
    Private f_blnDirty As Boolean       ' Have any changes been made
    Private f_blnResult As Boolean      ' Don't use DialogResult since it triggers a cascade close
    Private f_intPlayerID As Integer



    ' -------------------------------------------------------------------------
    ' Name: FAddPlayer_Load
    ' Abstract: Called when the form is loaded
    ' -------------------------------------------------------------------------
    Private Sub FAddPlayer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            ' Don't make any database calls here because the form isn't visible yet.
            ' The instance has been created but it hasn't been made visible with Show/ShowDialog.
            ' Do the database load code in Form_Activate so that the user sees the form
            ' and the busy cursor during the database call.

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: FAddPlayer_Activated
    ' Abstract: This is called when the form is shown (e.g. ShowDialog)
    '           OR when it receives the focus (switch to another application
    '           and then come back).  We load the Player to edit in this
    '           procedure because we want the user to see the edit form
    '           and to have a visual indicator that something is going on 
    '           (i.e. SetBusyCursor) since the LoadFromDB may take a while.
    '           We need a boolean loaded flag so that the load if fired only 
    '           once even if the activate event is fired multiple times.
    ' -------------------------------------------------------------------------
    Private Sub FAddPlayer_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated

        Try

            ' Have we loaded?
            If f_blnLoaded = False Then

                ' No but now we have
                f_blnLoaded = True

                ' Not successful
                f_blnResult = False

                ' We are busy
                SetBusyCursor(Me, True)

                ' Load States
                LoadComboBoxFromDatabase("TStates", "intStateID", "strState", cmbState)

                ' Clear dirty flag
                SetDirty(False)

                ' Set focus to first name 
                txtFirstName.Focus()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: txtField_TextChanged
    ' Abstract: Set the dirty flag if any field changes
    ' -------------------------------------------------------------------------
    Private Sub txtField_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                     Handles txtFirstName.TextChanged, _
                                             txtMiddleName.TextChanged, _
                                             txtLastName.TextChanged, _
                                             txtStreetAddress.TextChanged, _
                                             txtCity.TextChanged, _
                                             cmbState.SelectedIndexChanged, _
                                             txtZipCode.TextChanged, _
                                             txtHomePhoneNumber.TextChanged, _
                                             txtEmergencyContactName.TextChanged, _
                                             txtEmergencyContactPhoneNumber.TextChanged

        Try

            SetDirty(True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: If the data is good then save the changes
    ' -------------------------------------------------------------------------
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

        Try

            ' Is the data OK?
            If IsValidData() = True Then

                ' Yes, save
                If SaveData() = True Then

                    ' If the save was successful then ...

                    ' Success
                    f_blnResult = True

                    ' Hide
                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Validate the data on the form before adding to the database.
    ' -------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True   ' Assume good data

        Try
            Dim strErrorMessage As String = "Please correct the following errors:" & vbNewLine

            ' Trim any spaces
            TrimAllFormTextBoxes(Me)

            ' Is the First Name blank?
            If txtFirstName.Text = "" Then

                strErrorMessage = strErrorMessage & "-First Name cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Is the Last Name blank?
            If txtLastName.Text = "" Then

                strErrorMessage = strErrorMessage & "-Last Name cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Is the Home Phone Number blank?
            If txtHomePhoneNumber.Text = "" Then

                strErrorMessage = strErrorMessage & "-Home Phone Number cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Bad data?
            If blnIsValidData = False Then

                ' Yes, tell the user what they did wrong
                MessageBox.Show(strErrorMessage, Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function


    ' -------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Save the Player to the database
    ' -------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim udtPlayer As udtPlayerType

            ' Get values from form
            udtPlayer.intPlayerID = 0                       ' Will be returned from DB call
            udtPlayer.strFirstName = txtFirstName.Text
            udtPlayer.strMiddleName = txtMiddleName.Text
            udtPlayer.strLastName = txtLastName.Text
            udtPlayer.strStreetAddress = txtStreetAddress.Text
            udtPlayer.strCity = txtCity.Text
            udtPlayer.intStateID = cmbState.SelectedItem.GetID()
            udtPlayer.strZipCode = txtZipCode.Text
            udtPlayer.strHomePhoneNumber = txtHomePhoneNumber.Text
            udtPlayer.strEmergencyContactName = txtEmergencyContactName.Text
            udtPlayer.strEmergencyContactPhoneNumber = txtEmergencyContactPhoneNumber.Text

            ' We are busy
            SetBusyCursor(Me, True)

            ' Add to the database
            blnResult = AddPlayerToDatabase(udtPlayer)

            ' Did it work?
            If blnResult = True Then

                ' Yes, save the ID
                f_intPlayerID = udtPlayer.intPlayerID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form without saving changes
    ' -------------------------------------------------------------------------
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Try

            Dim drConfirm As DialogResult

            ' Has the user made changes?
            If GetDirty() = True Then

                ' Yes, confirm they want to cancel
                drConfirm = MessageBox.Show("Are you sure?", "Cancel " & Me.Text, _
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Are they sure?
                If drConfirm = DialogResult.Yes Then

                    ' Close the form
                    Me.Hide()

                End If

            Else

                ' No changes so just close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: GetDirty
    ' Abstract: Have changes been made to the form?
    ' -------------------------------------------------------------------------
    Public Function GetDirty() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnDirty

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetDirty
    ' Abstract: A change has been made to the form
    ' -------------------------------------------------------------------------
    Public Sub SetDirty(ByVal blnDirty As Boolean)

        Try

            f_blnDirty = blnDirty

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' -------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: GetNewPlayerInformation
    ' Abstract: Get the new Player information
    ' -------------------------------------------------------------------------
    Public Function GetNewPlayerInformation() As CListItem

        Dim clsPlayer As CListItem = Nothing

        Try

            Dim strPlayerName As String

            strPlayerName = txtLastName.Text + ", " + txtFirstName.Text

            clsPlayer = New CListItem(f_intPlayerID, strPlayerName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return clsPlayer

    End Function

End Class
