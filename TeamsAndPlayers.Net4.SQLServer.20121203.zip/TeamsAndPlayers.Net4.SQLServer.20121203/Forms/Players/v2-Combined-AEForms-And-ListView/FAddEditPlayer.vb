' -------------------------------------------------------------------------
'   Form: FAddEditPlayer
'   Purpose: Allow the user to add/edit a Player
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
'5  2012/09/19      P.C.    Minor tweaks
'
'   I combined the Add and Edit forms into this one since they're very
'   similar.
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FAddEditPlayer

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------
    Private f_blnLoaded As Boolean
    Private f_blnDirty As Boolean ' Have any changes been made
    Private f_blnAddPlayer As Boolean
    Private f_blnResult As Boolean      ' Don't use DialogResult since it triggers a cascade close
    Private f_intPlayerID As Integer


    ' -------------------------------------------------------------------------
    ' Name: FAddEditPlayer_Load
    ' Abstract: Called when the form is loaded
    ' -------------------------------------------------------------------------
    Private Sub FAddEditPlayer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            ' Don't make any database calls here because the form isn't visible yet.
            ' The instance has been created but it hasn't been made visible with Show/ShowDialog.
            ' Do the database load code in Form_Activate so that the user sees the form
            ' and the busy cursor during the database call.

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: SetFormValues
    ' Abstract: Set the form values: boolean flag for adding, Player ID if editing.
    ' -------------------------------------------------------------------------
    Public Sub SetFormValues(ByVal blnAddPlayer As Boolean, _
                             ByVal intPlayerID As Integer)

        Try

            ' Add or edit
            f_blnAddPlayer = blnAddPlayer

            ' Player ID
            f_intPlayerID = intPlayerID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: FAddEditPlayer_Activated
    ' Abstract: This is called when the form is shown (e.g. ShowDialog)
    '           OR when it receives the focus (switch to another application
    '           and then come back).  We load the Player to edit in this
    '           procedure because we want the user to see the edit form
    '           and to have a visual indicator that something is going on 
    '           (i.e. SetBusyCursor) since the LoadFromDB may take a while.
    '           We need a boolean loaded flag so that the load if fired only 
    '           once even if the activate event is fired multiple times.
    ' -------------------------------------------------------------------------
    Private Sub FAddEditPlayer_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated

        Try

            Dim blnResult As Boolean = False

            ' Have we loaded?
            If f_blnLoaded = False Then

                ' No but now we have
                f_blnLoaded = True

                ' We are busy
                SetBusyCursor(Me, True)

                ' Load States
                LoadComboBoxFromDatabase("TStates", "intStateID", "strState", cmbState)

                ' Add or Edit?
                If f_blnAddPlayer = True Then

                    Me.Text = "Add Player"

                Else

                    Me.Text = "Edit Player"

                    ' Load the exiting Player data
                    blnResult = LoadPlayer()

                    ' Did it work?
                    If blnResult = False Then

                        ' No, so cancel the edit
                        MessageBox.Show("Unable to load team information from the database" & vbNewLine & _
                                        "Action cancelled.", Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        ' Close
                        Me.Close()

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadPlayer
    ' Abstract: Get the Player information from the database and populate the
    '           form field with it
    ' -------------------------------------------------------------------------
    Private Function LoadPlayer() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim udtPlayer As udtPlayerType = New udtPlayerType

            ' Which Player do we edit?
            udtPlayer.intPlayerID = f_intPlayerID

            ' Load the player information
            blnResult = GetPlayerInformationFromDatabase(udtPlayer)

            ' Did it work?
            If blnResult = True Then

                ' Yes
                txtFirstName.Text = udtPlayer.strFirstName
                txtMiddleName.Text = udtPlayer.strMiddleName
                txtLastName.Text = udtPlayer.strLastName
                txtStreetAddress.Text = udtPlayer.strStreetAddress
                txtCity.Text = udtPlayer.strCity
                SelectItemInListFromID(cmbState, udtPlayer.intStateID)
                txtZipCode.Text = udtPlayer.strZipCode
                txtHomePhoneNumber.Text = udtPlayer.strHomePhoneNumber
                txtEmergencyContactName.Text = udtPlayer.strEmergencyContactName
                txtEmergencyContactPhoneNumber.Text = udtPlayer.strEmergencyContactPhoneNumber

                ' Set focus to Player name and select existing text
                txtFirstName.Focus()
                txtFirstName.SelectAll()

                ' Clear dirty flag
                SetDirty(False)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: txtField_TextChanged
    ' Abstract: Set the dirty flag if any field changes
    ' -------------------------------------------------------------------------
    Private Sub txtField_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                     Handles txtFirstName.TextChanged, _
                                             txtMiddleName.TextChanged, _
                                             txtLastName.TextChanged, _
                                             txtStreetAddress.TextChanged, _
                                             txtCity.TextChanged, _
                                             cmbState.SelectedIndexChanged, _
                                             txtZipCode.TextChanged, _
                                             txtHomePhoneNumber.TextChanged, _
                                             txtEmergencyContactName.TextChanged, _
                                             txtEmergencyContactPhoneNumber.TextChanged

        Try

            SetDirty(True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: If the data is good then save the changes
    ' -------------------------------------------------------------------------
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

        Try

            ' Is the data OK?
            If IsValidData() = True Then

                ' Yes, save
                If SaveData() = True Then

                    ' If the save was successful then ...

                    ' Success
                    f_blnResult = True

                    ' Hide
                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Validate the data on the form before adding to the database.
    ' -------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True   ' Assume good data

        Try

            Dim strErrorMessage As String = "Please correct the following errors:" & vbNewLine

            ' Trim any spaces
            TrimAllFormTextBoxes(Me)

            ' Is the First Name blank?
            If txtFirstName.Text = "" Then

                strErrorMessage = strErrorMessage & "-First Name cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Is the Last Name blank?
            If txtLastName.Text = "" Then

                strErrorMessage = strErrorMessage & "-Last Name cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Is the Home Phone Number blank?
            If txtHomePhoneNumber.Text = "" Then

                strErrorMessage = strErrorMessage & "-Home Phone Number cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Bad data?
            If blnIsValidData = False Then

                ' Yes, tell the user what they did wrong
                MessageBox.Show(strErrorMessage, Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function


    ' -------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Save the Player to the database
    ' -------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim udtPlayer As udtPlayerType

            ' Get values from form
            udtPlayer.intPlayerID = f_intPlayerID
            udtPlayer.strFirstName = txtFirstName.Text
            udtPlayer.strMiddleName = txtMiddleName.Text
            udtPlayer.strLastName = txtLastName.Text
            udtPlayer.strStreetAddress = txtStreetAddress.Text
            udtPlayer.strCity = txtCity.Text
            udtPlayer.intStateID = cmbState.SelectedItem.GetID()
            udtPlayer.strZipCode = txtZipCode.Text
            udtPlayer.strHomePhoneNumber = txtHomePhoneNumber.Text
            udtPlayer.strEmergencyContactName = txtEmergencyContactName.Text
            udtPlayer.strEmergencyContactPhoneNumber = txtEmergencyContactPhoneNumber.Text

            ' We are busy
            SetBusyCursor(Me, True)

            ' Add or Edit?
            If f_blnAddPlayer = True Then

                ' Add
                blnResult = AddPlayerToDatabase(udtPlayer)

                ' Did it work?
                If blnResult = True Then

                    ' Yes, save the ID
                    f_intPlayerID = udtPlayer.intPlayerID

                End If

            Else

                ' Edit
                blnResult = EditPlayerInDatabase(udtPlayer)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form without saving changes
    ' -------------------------------------------------------------------------
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Try

            Dim drConfirm As DialogResult

            ' Has the user made changes?
            If GetDirty() = True Then

                ' Yes, confirm they want to cancel
                drConfirm = MessageBox.Show("Are you sure?", "Cancel " & Me.Text, _
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Are they sure?
                If drConfirm = DialogResult.Yes Then

                    ' Close the form
                    Me.Hide()

                End If

            Else

                ' No changes so just close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: GetDirty
    ' Abstract: Have changes been made to the form?
    ' -------------------------------------------------------------------------
    Public Function GetDirty() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnDirty

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetDirty
    ' Abstract: A change has been made to the form
    ' -------------------------------------------------------------------------
    Public Sub SetDirty(ByVal blnDirty As Boolean)

        Try

            f_blnDirty = blnDirty

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' -------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: GetNewPlayerInformation
    ' Abstract: Get the new Player information
    ' -------------------------------------------------------------------------
    Public Function GetNewPlayerInformation() As ListViewItem

        Dim lviPlayer As ListViewItem = Nothing

        Try

            lviPlayer = New ListViewItem()
            lviPlayer.Tag = f_intPlayerID
            lviPlayer.Text = txtLastName.Text
            lviPlayer.SubItems.Add(txtFirstName.Text)
            lviPlayer.SubItems.Add(txtHomePhoneNumber.Text)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return lviPlayer

    End Function

End Class
