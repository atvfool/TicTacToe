<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManagePlayersV2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblPlayers = New System.Windows.Forms.Label()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lvwPlayers = New System.Windows.Forms.ListView()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblPlayers
        '
        Me.lblPlayers.Location = New System.Drawing.Point(12, 9)
        Me.lblPlayers.Name = "lblPlayers"
        Me.lblPlayers.Size = New System.Drawing.Size(96, 16)
        Me.lblPlayers.TabIndex = 17
        Me.lblPlayers.Text = "Players"
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(300, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(88, 32)
        Me.btnDelete.TabIndex = 3
        Me.btnDelete.Text = "&Delete"
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(300, 105)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(88, 32)
        Me.btnEdit.TabIndex = 2
        Me.btnEdit.Text = "&Edit"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(300, 41)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(88, 32)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "&Add"
        '
        'lvwPlayers
        '
        Me.lvwPlayers.Location = New System.Drawing.Point(11, 25)
        Me.lvwPlayers.Name = "lvwPlayers"
        Me.lvwPlayers.Size = New System.Drawing.Size(273, 199)
        Me.lvwPlayers.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvwPlayers.TabIndex = 18
        Me.lvwPlayers.UseCompatibleStateImageBehavior = False
        Me.lvwPlayers.View = System.Windows.Forms.View.Details
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.Location = New System.Drawing.Point(14, 229)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(93, 17)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(128, 253)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(148, 32)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close"
        '
        'FManagePlayersV2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 308)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lvwPlayers)
        Me.Controls.Add(Me.lblPlayers)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManagePlayersV2"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Players v2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblPlayers As System.Windows.Forms.Label
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lvwPlayers As System.Windows.Forms.ListView
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
