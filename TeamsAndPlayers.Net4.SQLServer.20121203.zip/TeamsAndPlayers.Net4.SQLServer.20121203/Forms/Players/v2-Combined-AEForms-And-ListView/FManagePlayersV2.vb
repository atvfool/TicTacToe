' -------------------------------------------------------------------------
'   Form: FManagePlayers
'   Purpose: Allow the user to manage( add/edit/delete ) a Player
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FManagePlayersV2

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------



    ' -------------------------------------------------------------------------
    ' Name: FManagePlayers_Load
    ' Abstract: Do any initialization
    ' -------------------------------------------------------------------------
    Private Sub FManagePlayers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            ' This may take a while
            Me.Show()

            InitializeListView()

            LoadPlayerList()

            ' Set the focus
            lvwPlayers.Focus()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadPlayerList
    ' Abstract: Load the Player list
    ' -------------------------------------------------------------------------
    Private Sub LoadPlayerList()

        Try

            Dim strSelect As String = ""
            Dim strPlayerStatusID As String = ""

            ' Active or Deleted players?
            If chkShowDeleted.Checked = False Then

                ' Active
                strPlayerStatusID = intPLAYER_STATUS_ACTIVE

            Else

                ' Deleted
                strPlayerStatusID = intPLAYER_STATUS_INACTIVE

            End If

            ' Custom SELECT statement
            strSelect = "SELECT intPlayerID, strLastName, strFirstName, strHomePhoneNumber " & _
                        " FROM TPlayers" & _
                        " WHERE intPlayerStatusID = " & strPlayerStatusID & _
                        " ORDER BY strLastName, strFirstName"

            ' We are busy
            SetBusyCursor(Me, True)

            LoadListViewFromDatabase("", "", Nothing, lvwPlayers, "", strSelect)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: InitializeListView
    ' Abstract: Set the display style and the columns
    ' -------------------------------------------------------------------------
    Private Sub InitializeListView()

        Try

            Dim intNumberOfColumns As Integer = 3
            Dim intColumnWidth As Integer

            ' This makes it a list view.  Otherwise we won't see any changes since the default is icon view
            lvwPlayers.View = View.Details

            ' Clear any existing items
            lvwPlayers.Items.Clear()

            ' Select only one row at a time
            lvwPlayers.MultiSelect = False

            ' Select the whole row no matter what column is clicked
            lvwPlayers.FullRowSelect = True

            ' Show selected item even when control loses focus
            lvwPlayers.HideSelection = False

            ' Sort alphabetically
            lvwPlayers.Sorting = SortOrder.Ascending

            ' Add the columns (divide evenyly and subtract 1 pixel from each column for divider between )
            intColumnWidth = lvwPlayers.Width / intNumberOfColumns - intNumberOfColumns
            lvwPlayers.Columns.Add("Last Name", intColumnWidth)
            lvwPlayers.Columns.Add("First Name", intColumnWidth)
            lvwPlayers.Columns.Add("Home Phone Number", intColumnWidth)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Player
    ' -------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        Try

            AddPlayer()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: AddPlayer
    ' Abstract: Add a Player
    ' -------------------------------------------------------------------------
    Private Sub AddPlayer()

        Try

            Dim frmAddEditPlayer As FAddEditPlayer
            Dim lviPlayer As ListViewItem

            ' Create form
            frmAddEditPlayer = New FAddEditPlayer

            ' Set the form values
            frmAddEditPlayer.SetFormValues(True, 0)

            ' Show it
            frmAddEditPlayer.ShowDialog(Me)

            ' Was the Add successful?
            If frmAddEditPlayer.GetResult = True Then

                ' Get the new Player information
                lviPlayer = frmAddEditPlayer.GetNewPlayerInformation()

                ' Add the item to the list and select it
                lvwPlayers.Items.Add(lviPlayer)
                lviPlayer.Selected = True

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: lvwPlayers_DoubleClick
    ' Abstract: Same as clicking edit
    ' -------------------------------------------------------------------------
    Private Sub lvwPlayers_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwPlayers.DoubleClick

        Try

            ' Same as clicking edit
            EditPlayer()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the currently selected Player
    ' -------------------------------------------------------------------------
    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click

        Try

            EditPlayer()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: EditPlayer
    ' Abstract: Edit the currently selected Player
    ' -------------------------------------------------------------------------
    Private Sub EditPlayer()

        Try

            Dim frmAddEditPlayer As FAddEditPlayer

            Dim intSelectedPlayerID As Integer
            Dim lviPlayer As ListViewItem

            ' Get the selected Player ID
            intSelectedPlayerID = GetSelectedListItemID(lvwPlayers)

            ' Is a Player selected?
            If intSelectedPlayerID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, create form
                frmAddEditPlayer = New FAddEditPlayer

                ' Yes, set the form values
                frmAddEditPlayer.SetFormValues(False, intSelectedPlayerID)

                ' Show it
                frmAddEditPlayer.ShowDialog(Me)

                ' Was the Add successful?
                If frmAddEditPlayer.GetResult = True Then

                    ' Get the new Player information
                    lviPlayer = frmAddEditPlayer.GetNewPlayerInformation()

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lvwPlayers.Items.RemoveAt(lvwPlayers.SelectedItems.Item(0).Index)
                    lvwPlayers.Items.Add(lviPlayer)
                    lviPlayer.Selected = True

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the currently selected Player.
    ' -------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click

        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeletePlayer()

            Else

                ' No, undelete
                UndeletePlayer()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: DeletePlayer
    ' Abstract: Delete the currently selected Player.
    ' -------------------------------------------------------------------------
    Private Sub DeletePlayer()

        Try

            Dim intSelectedPlayerID As Integer
            Dim strSelectedPlayerName As String
            Dim intSelectedPlayerIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Get the selected Player ID
            intSelectedPlayerID = GetSelectedListItemID(lvwPlayers)

            ' Is a Player selected?
            If intSelectedPlayerID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Player name and list index
                strSelectedPlayerName = lvwPlayers.Items.Item(lvwPlayers.SelectedIndices(0)).Text
                intSelectedPlayerIndex = lvwPlayers.SelectedIndices(0)

                ' Yes, confirm they want to delete
                drConfirm = MessageBox.Show("Are you sure?", "Delete Player: " & strSelectedPlayerName, _
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Player and all the Player players assignments
                    blnResult = DeletePlayerFromDatabase(intSelectedPlayerID)

                    ' Was the delete successful?
                    If blnResult = True Then

                        ' Yes, remove the Player from the list
                        lvwPlayers.Items.RemoveAt(intSelectedPlayerIndex)

                        ' Select the next Player in the list
                        HighlightNextItemInList(lvwPlayers, intSelectedPlayerIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: UndeletePlayer
    ' Abstract: Undelete the currently selected Player.
    ' -------------------------------------------------------------------------
    Private Sub UndeletePlayer()

        Try

            Dim intSelectedPlayerID As Integer
            Dim intSelectedPlayerIndex As Integer
            Dim blnResult As Boolean

            ' Get the selected Player ID
            intSelectedPlayerID = GetSelectedListItemID(lvwPlayers)

            ' Is a Player selected?
            If intSelectedPlayerID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the list index
                intSelectedPlayerIndex = lvwPlayers.SelectedIndices(0)

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, delete the Player and all the Player players assignments
                blnResult = UndeletePlayerFromDatabase(intSelectedPlayerID)

                ' Was the delete successful?
                If blnResult = True Then

                    ' Yes, remove the Player from the list
                    lvwPlayers.Items.RemoveAt(intSelectedPlayerIndex)

                    ' Select the next Player in the list
                    HighlightNextItemInList(lvwPlayers, intSelectedPlayerIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active and inactive teams
    ' -------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowDeleted.CheckedChanged

        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            LoadPlayerList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form
    ' -------------------------------------------------------------------------
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Try

            ' Goodbye cruel world
            Me.Hide()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

End Class
