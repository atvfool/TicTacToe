<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAssignTeamPlayers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbTeams = New System.Windows.Forms.ComboBox()
        Me.fraPlayers = New System.Windows.Forms.GroupBox()
        Me.lblAvailablePlayers = New System.Windows.Forms.Label()
        Me.lblSelectedPlayers = New System.Windows.Forms.Label()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lstAvailablePlayers = New System.Windows.Forms.ListBox()
        Me.lstSelectedPlayers = New System.Windows.Forms.ListBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblTeam = New System.Windows.Forms.Label()
        Me.fraPlayers.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmbTeams
        '
        Me.cmbTeams.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTeams.Location = New System.Drawing.Point(63, 9)
        Me.cmbTeams.Name = "cmbTeams"
        Me.cmbTeams.Size = New System.Drawing.Size(168, 21)
        Me.cmbTeams.Sorted = True
        Me.cmbTeams.TabIndex = 15
        '
        'fraPlayers
        '
        Me.fraPlayers.Controls.Add(Me.lblAvailablePlayers)
        Me.fraPlayers.Controls.Add(Me.lblSelectedPlayers)
        Me.fraPlayers.Controls.Add(Me.btnRemove)
        Me.fraPlayers.Controls.Add(Me.btnAdd)
        Me.fraPlayers.Controls.Add(Me.lstAvailablePlayers)
        Me.fraPlayers.Controls.Add(Me.lstSelectedPlayers)
        Me.fraPlayers.Location = New System.Drawing.Point(15, 41)
        Me.fraPlayers.Name = "fraPlayers"
        Me.fraPlayers.Size = New System.Drawing.Size(472, 240)
        Me.fraPlayers.TabIndex = 14
        Me.fraPlayers.TabStop = False
        Me.fraPlayers.Text = "Players"
        '
        'lblAvailablePlayers
        '
        Me.lblAvailablePlayers.AutoSize = True
        Me.lblAvailablePlayers.Location = New System.Drawing.Point(296, 24)
        Me.lblAvailablePlayers.Name = "lblAvailablePlayers"
        Me.lblAvailablePlayers.Size = New System.Drawing.Size(53, 13)
        Me.lblAvailablePlayers.TabIndex = 15
        Me.lblAvailablePlayers.Text = "Available:"
        '
        'lblSelectedPlayers
        '
        Me.lblSelectedPlayers.AutoSize = True
        Me.lblSelectedPlayers.Location = New System.Drawing.Point(16, 24)
        Me.lblSelectedPlayers.Name = "lblSelectedPlayers"
        Me.lblSelectedPlayers.Size = New System.Drawing.Size(52, 13)
        Me.lblSelectedPlayers.TabIndex = 14
        Me.lblSelectedPlayers.Text = "Selected:"
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(192, 144)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(88, 24)
        Me.btnRemove.TabIndex = 4
        Me.btnRemove.Text = "&Remove >"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(192, 96)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(88, 24)
        Me.btnAdd.TabIndex = 3
        Me.btnAdd.Text = "< &Add"
        '
        'lstAvailablePlayers
        '
        Me.lstAvailablePlayers.Location = New System.Drawing.Point(296, 40)
        Me.lstAvailablePlayers.Name = "lstAvailablePlayers"
        Me.lstAvailablePlayers.Size = New System.Drawing.Size(160, 186)
        Me.lstAvailablePlayers.Sorted = True
        Me.lstAvailablePlayers.TabIndex = 6
        '
        'lstSelectedPlayers
        '
        Me.lstSelectedPlayers.Location = New System.Drawing.Point(16, 40)
        Me.lstSelectedPlayers.Name = "lstSelectedPlayers"
        Me.lstSelectedPlayers.Size = New System.Drawing.Size(160, 186)
        Me.lstSelectedPlayers.Sorted = True
        Me.lstSelectedPlayers.TabIndex = 1
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(199, 296)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(104, 32)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Text = "&Close"
        '
        'lblTeam
        '
        Me.lblTeam.AutoSize = True
        Me.lblTeam.Location = New System.Drawing.Point(15, 12)
        Me.lblTeam.Name = "lblTeam"
        Me.lblTeam.Size = New System.Drawing.Size(37, 13)
        Me.lblTeam.TabIndex = 12
        Me.lblTeam.Text = "Team:"
        '
        'FAssignTeamPlayers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClose
        Me.ClientSize = New System.Drawing.Size(502, 339)
        Me.Controls.Add(Me.cmbTeams)
        Me.Controls.Add(Me.fraPlayers)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblTeam)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAssignTeamPlayers"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Assign Team Players"
        Me.fraPlayers.ResumeLayout(False)
        Me.fraPlayers.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbTeams As System.Windows.Forms.ComboBox
    Friend WithEvents fraPlayers As System.Windows.Forms.GroupBox
    Friend WithEvents lblAvailablePlayers As System.Windows.Forms.Label
    Friend WithEvents lblSelectedPlayers As System.Windows.Forms.Label
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lstAvailablePlayers As System.Windows.Forms.ListBox
    Friend WithEvents lstSelectedPlayers As System.Windows.Forms.ListBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblTeam As System.Windows.Forms.Label
End Class
