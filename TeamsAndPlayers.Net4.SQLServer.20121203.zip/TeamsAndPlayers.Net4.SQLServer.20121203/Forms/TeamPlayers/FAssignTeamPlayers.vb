' -------------------------------------------------------------------------
'   Form: FAssignTeamPlayers
'   Purpose: Allow the user to select manage players on a team
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FAssignTeamPlayers

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------



    ' -------------------------------------------------------------------------
    ' Name: Form_Load
    ' Abstract: Do any initialization
    ' -------------------------------------------------------------------------
    Private Sub FAssignTeamPlayers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            LoadTeamList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadTeamList
    ' Abstract: Load the team list
    ' -------------------------------------------------------------------------
    Private Sub LoadTeamList()

        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load the team list
            LoadComboBoxFromDatabase("VActiveTeams", "intTeamID", "strTeam", cmbTeams)

            ' Clear the selection
            cmbTeams.SelectedIndex = -1

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: cmbTeams_Click
    ' Abstract: Load the selected and available player lists for the current
    '           team.
    ' -------------------------------------------------------------------------
    Private Sub cmbTeams_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbTeams.SelectedIndexChanged

        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load players for selected team
            LoadSelectedPlayersList()
            LoadAvailablePlayersList()

            ' Enable/disable  add/remove buttons
            EnableButtons()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: LoadSelectedPlayersList
    ' Abstract: Load the selected player list
    ' -------------------------------------------------------------------------
    Private Sub LoadSelectedPlayersList()

        Try

            Dim intTeamID As Integer

            ' Clear the list
            lstSelectedPlayers.Items.Clear()

            intTeamID = GetSelectedTeamID()

            ' Is a team selected?
            If intTeamID > 0 Then

                ' Load the selected player list
                LoadListWithPlayersFromDatabase(intTeamID, lstSelectedPlayers, True)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadAvailablePlayersList
    ' Abstract: Load the available player list
    ' -------------------------------------------------------------------------
    Private Sub LoadAvailablePlayersList()

        Try

            Dim intTeamID As Integer

            ' Clear the list
            lstAvailablePlayers.Items.Clear()

            intTeamID = GetSelectedTeamID()

            ' Is a team selected?
            If intTeamID > 0 Then

                ' Load the available player list
                LoadListWithPlayersFromDatabase(intTeamID, lstAvailablePlayers, False)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' -------------------------------------------------------------------------
    Private Sub EnableButtons()

        Try

            ' Any available players to add?
            btnAdd.Enabled = False
            If lstAvailablePlayers.Items.Count > 0 Then btnAdd.Enabled = True

            ' Any Selected players to add?
            btnRemove.Enabled = False
            If lstSelectedPlayers.Items.Count > 0 Then btnRemove.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetSelectedTeamID
    ' Abstract: Get the selected team ID
    ' -------------------------------------------------------------------------
    Private Function GetSelectedTeamID() As Integer

        Dim intSelectedTeamID As Integer = 0

        Try

            Dim clsSelectedTeam As CListItem

            ' Is there anything in the list?
            If cmbTeams.Items.Count > 0 Then

                ' Yes, is anything selected?
                If cmbTeams.SelectedIndex >= 0 Then

                    ' Yes, get the team ID
                    clsSelectedTeam = cmbTeams.SelectedItem
                    intSelectedTeamID = clsSelectedTeam.GetID

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return intSelectedTeamID

    End Function



    ' -------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Player
    ' -------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        Try

            AddPlayerToTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: lstAvailablePlayers_DblClick
    ' Abstract: Same as clicking add
    ' -------------------------------------------------------------------------
    Private Sub lstAvailablePlayers_DblClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstAvailablePlayers.DoubleClick

        Try

            ' Same as clicking Add
            AddPlayerToTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: AddPlayerToTeam
    ' Abstract: Add a Player to a team
    ' -------------------------------------------------------------------------
    Private Sub AddPlayerToTeam()

        Try

            Dim clsListItem As CListItem
            Dim intTeamID As Integer
            Dim intPlayerID As Integer
            Dim intIndex As Integer

            ' Is a team selected?
            If cmbTeams.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Team.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' Is a player selected?
            ElseIf lstAvailablePlayers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to add.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Team and Player IDs
                clsListItem = cmbTeams.SelectedItem
                intTeamID = clsListItem.GetID
                clsListItem = lstAvailablePlayers.SelectedItem
                intPlayerID = clsListItem.GetID

                ' Add the player
                If AddPlayerToTeamInDatabase(intTeamID, intPlayerID) = True Then

                    ' Add to selected players
                    intIndex = lstSelectedPlayers.Items.Add(lstAvailablePlayers.SelectedItem)
                    lstSelectedPlayers.SelectedIndex = intIndex

                    ' Remove from available players
                    intIndex = lstAvailablePlayers.SelectedIndex
                    lstAvailablePlayers.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailablePlayers, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected Player from the team.
    ' -------------------------------------------------------------------------
    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click

        Try

            RemovePlayerFromTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: lstSelectedPlayers_DblClick
    ' Abstract: Same as clicking Remove
    ' -------------------------------------------------------------------------
    Private Sub lstSelectedPlayers_DblClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSelectedPlayers.DoubleClick

        Try

            ' Same as clicking Remove
            RemovePlayerFromTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: RemovePlayerFromTeam
    ' Abstract: Remove the currently selected Player from the team.
    ' -------------------------------------------------------------------------
    Private Sub RemovePlayerFromTeam()

        Try

            Dim clsListItem As CListItem
            Dim intTeamID As Integer
            Dim intPlayerID As Integer
            Dim intIndex As Integer

            ' Is a team selected?
            If cmbTeams.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Team.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' Is a player selected?
            ElseIf lstSelectedPlayers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Player to Remove.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Team and Player IDs
                clsListItem = cmbTeams.SelectedItem
                intTeamID = clsListItem.GetID
                clsListItem = lstSelectedPlayers.SelectedItem
                intPlayerID = clsListItem.GetID

                ' Remove the player
                If RemovePlayerFromTeamInDatabase(intTeamID, intPlayerID) = True Then

                    ' Add to available players
                    intIndex = lstAvailablePlayers.Items.Add(lstSelectedPlayers.SelectedItem)
                    lstAvailablePlayers.SelectedIndex = intIndex

                    ' Remove from selected players
                    intIndex = lstSelectedPlayers.SelectedIndex
                    lstSelectedPlayers.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedPlayers, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try


    End Sub



    ' -------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Unload the form
    ' -------------------------------------------------------------------------
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Try

            ' Goodbye cruel world
            Me.Hide()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

End Class

