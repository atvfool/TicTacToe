<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.mnuAssignTeamPlayers = New System.Windows.Forms.MenuItem()
        Me.mnuManageTeams = New System.Windows.Forms.MenuItem()
        Me.mnuManage = New System.Windows.Forms.MenuItem()
        Me.mnuManagePlayersV1 = New System.Windows.Forms.MenuItem()
        Me.mnuManagePlayersV2 = New System.Windows.Forms.MenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.MenuItem()
        Me.mnuHelp = New System.Windows.Forms.MenuItem()
        Me.mnuFileExit = New System.Windows.Forms.MenuItem()
        Me.btnAssignTeamPlayers = New System.Windows.Forms.Button()
        Me.btnManagePlayersV1 = New System.Windows.Forms.Button()
        Me.fraManage = New System.Windows.Forms.GroupBox()
        Me.btnManagePlayersV2 = New System.Windows.Forms.Button()
        Me.btnManageTeams = New System.Windows.Forms.Button()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuMenu = New System.Windows.Forms.MainMenu(Me.components)
        Me.fraManage.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuAssignTeamPlayers
        '
        Me.mnuAssignTeamPlayers.Index = 1
        Me.mnuAssignTeamPlayers.Text = "T&eam Players"
        '
        'mnuManageTeams
        '
        Me.mnuManageTeams.Index = 0
        Me.mnuManageTeams.Text = "&Teams"
        '
        'mnuManage
        '
        Me.mnuManage.Index = 1
        Me.mnuManage.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuManageTeams, Me.mnuAssignTeamPlayers, Me.mnuManagePlayersV1, Me.mnuManagePlayersV2})
        Me.mnuManage.Text = "&Manage"
        '
        'mnuManagePlayersV1
        '
        Me.mnuManagePlayersV1.Index = 2
        Me.mnuManagePlayersV1.Text = "&Players v1"
        '
        'mnuManagePlayersV2
        '
        Me.mnuManagePlayersV2.Index = 3
        Me.mnuManagePlayersV2.Text = "Players v2"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Index = 0
        Me.mnuHelpAbout.Text = "&About"
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 2
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpAbout})
        Me.mnuHelp.Text = "&Help"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Index = 0
        Me.mnuFileExit.Text = "E&xit"
        '
        'btnAssignTeamPlayers
        '
        Me.btnAssignTeamPlayers.Location = New System.Drawing.Point(24, 74)
        Me.btnAssignTeamPlayers.Name = "btnAssignTeamPlayers"
        Me.btnAssignTeamPlayers.Size = New System.Drawing.Size(148, 32)
        Me.btnAssignTeamPlayers.TabIndex = 5
        Me.btnAssignTeamPlayers.Text = "Team Players"
        '
        'btnManagePlayersV1
        '
        Me.btnManagePlayersV1.Location = New System.Drawing.Point(24, 123)
        Me.btnManagePlayersV1.Name = "btnManagePlayersV1"
        Me.btnManagePlayersV1.Size = New System.Drawing.Size(148, 32)
        Me.btnManagePlayersV1.TabIndex = 6
        Me.btnManagePlayersV1.Text = "Players v1"
        '
        'fraManage
        '
        Me.fraManage.Controls.Add(Me.btnManagePlayersV2)
        Me.fraManage.Controls.Add(Me.btnManagePlayersV1)
        Me.fraManage.Controls.Add(Me.btnAssignTeamPlayers)
        Me.fraManage.Controls.Add(Me.btnManageTeams)
        Me.fraManage.Location = New System.Drawing.Point(24, 16)
        Me.fraManage.Name = "fraManage"
        Me.fraManage.Size = New System.Drawing.Size(196, 229)
        Me.fraManage.TabIndex = 7
        Me.fraManage.TabStop = False
        Me.fraManage.Text = "Manage"
        '
        'btnManagePlayersV2
        '
        Me.btnManagePlayersV2.Location = New System.Drawing.Point(24, 172)
        Me.btnManagePlayersV2.Name = "btnManagePlayersV2"
        Me.btnManagePlayersV2.Size = New System.Drawing.Size(148, 32)
        Me.btnManagePlayersV2.TabIndex = 7
        Me.btnManagePlayersV2.Text = "Players v2"
        '
        'btnManageTeams
        '
        Me.btnManageTeams.Location = New System.Drawing.Point(24, 25)
        Me.btnManageTeams.Name = "btnManageTeams"
        Me.btnManageTeams.Size = New System.Drawing.Size(148, 32)
        Me.btnManageTeams.TabIndex = 4
        Me.btnManageTeams.Text = "Teams"
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileExit})
        Me.mnuFile.Text = "&File"
        '
        'mnuMenu
        '
        Me.mnuMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuManage, Me.mnuHelp})
        '
        'FMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(244, 267)
        Me.Controls.Add(Me.fraManage)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Menu = Me.mnuMenu
        Me.MinimizeBox = False
        Me.Name = "FMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Teams And Players - MS Access"
        Me.fraManage.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents mnuAssignTeamPlayers As System.Windows.Forms.MenuItem
    Friend WithEvents mnuManageTeams As System.Windows.Forms.MenuItem
    Friend WithEvents mnuManage As System.Windows.Forms.MenuItem
    Friend WithEvents mnuManagePlayersV1 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelpAbout As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFileExit As System.Windows.Forms.MenuItem
    Friend WithEvents btnAssignTeamPlayers As System.Windows.Forms.Button
    Friend WithEvents btnManagePlayersV1 As System.Windows.Forms.Button
    Friend WithEvents fraManage As System.Windows.Forms.GroupBox
    Friend WithEvents btnManageTeams As System.Windows.Forms.Button
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMenu As System.Windows.Forms.MainMenu
    Friend WithEvents btnManagePlayersV2 As System.Windows.Forms.Button
    Friend WithEvents mnuManagePlayersV2 As System.Windows.Forms.MenuItem

End Class
