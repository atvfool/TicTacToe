<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAddTeam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblRequiredField = New System.Windows.Forms.Label()
        Me.lblMascot = New System.Windows.Forms.Label()
        Me.lblTeam = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtMascot = New System.Windows.Forms.TextBox()
        Me.txtTeam = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblRequiredField
        '
        Me.lblRequiredField.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequiredField.Location = New System.Drawing.Point(84, 70)
        Me.lblRequiredField.Name = "lblRequiredField"
        Me.lblRequiredField.Size = New System.Drawing.Size(120, 16)
        Me.lblRequiredField.TabIndex = 13
        Me.lblRequiredField.Text = "* Required Field"
        '
        'lblMascot
        '
        Me.lblMascot.AutoSize = True
        Me.lblMascot.Location = New System.Drawing.Point(28, 49)
        Me.lblMascot.Name = "lblMascot"
        Me.lblMascot.Size = New System.Drawing.Size(49, 13)
        Me.lblMascot.TabIndex = 12
        Me.lblMascot.Text = "Mascot:*"
        '
        'lblTeam
        '
        Me.lblTeam.AutoSize = True
        Me.lblTeam.Location = New System.Drawing.Point(28, 17)
        Me.lblTeam.Name = "lblTeam"
        Me.lblTeam.Size = New System.Drawing.Size(41, 13)
        Me.lblTeam.TabIndex = 11
        Me.lblTeam.Text = "Team:*"
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(144, 97)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(88, 26)
        Me.btnCancel.TabIndex = 10
        Me.btnCancel.Text = "&Cancel"
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(32, 97)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(88, 26)
        Me.btnOK.TabIndex = 9
        Me.btnOK.Text = "&OK"
        '
        'txtMascot
        '
        Me.txtMascot.Location = New System.Drawing.Point(84, 46)
        Me.txtMascot.MaxLength = 50
        Me.txtMascot.Name = "txtMascot"
        Me.txtMascot.Size = New System.Drawing.Size(152, 20)
        Me.txtMascot.TabIndex = 8
        '
        'txtTeam
        '
        Me.txtTeam.Location = New System.Drawing.Point(84, 14)
        Me.txtTeam.MaxLength = 50
        Me.txtTeam.Name = "txtTeam"
        Me.txtTeam.Size = New System.Drawing.Size(152, 20)
        Me.txtTeam.TabIndex = 7
        '
        'FAddTeam
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(264, 141)
        Me.Controls.Add(Me.lblRequiredField)
        Me.Controls.Add(Me.lblMascot)
        Me.Controls.Add(Me.lblTeam)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtMascot)
        Me.Controls.Add(Me.txtTeam)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAddTeam"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Add Team"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblRequiredField As System.Windows.Forms.Label
    Friend WithEvents lblMascot As System.Windows.Forms.Label
    Friend WithEvents lblTeam As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtMascot As System.Windows.Forms.TextBox
    Friend WithEvents txtTeam As System.Windows.Forms.TextBox
End Class
