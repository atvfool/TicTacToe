' -------------------------------------------------------------------------
'   Form: FEditTeam
'   Purpose: Allow the user to add/edit a team
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
'5  2012/09/19      P.C.    Minor tweaks
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FEditTeam
    
    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------
    Private f_blnLoaded As Boolean
    Private f_blnDirty As Boolean       ' Have any changes been made?
    Private f_blnResult As Boolean      ' Don't use DialogResult since it triggers a cascade close
    Private f_intTeamID As Integer


    ' -------------------------------------------------------------------------
    ' Name: SetFormValues
    ' Abstract: What team are we going to edit.
    '           Called after instance is created but before shown.
    ' -------------------------------------------------------------------------
    Public Sub SetFormValues(ByVal intTeamID As Integer)

        Try

            ' Team ID
            f_intTeamID = intTeamID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: FEditTeam_Activated
    ' Abstract: This is called when the form is shown (e.g. ShowDialog)
    '           OR when it receives the focus (switch to another application
    '           and then come back).  We load the team to edit in this
    '           procedure because we want the user to see the edit form
    '           and to have a visual indicator that something is going on 
    '           (i.e. SetBusyCursor) since the LoadFromDB may take a while.
    '           We need a boolean loaded flag so that the load if fired only 
    '           once even if the activate event is fired multiple times.
    ' -------------------------------------------------------------------------
    Private Sub FEditTeam_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated

        Try

            Dim blnResult As Boolean = False

            ' Have we loaded?
            If f_blnLoaded = False Then

                ' No but now we have
                f_blnLoaded = True

                ' Load the exiting Team data
                blnResult = LoadTeam()

                ' Did it work?
                If blnResult = False Then

                    ' No, so cancel the edit
                    MessageBox.Show("Unable to load team information from the database" & vbNewLine & _
                                    "Action cancelled.", Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' Close
                    Me.Close()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadTeam
    ' Abstract: Get the team information from the database and populate the
    '           form field with it
    ' -------------------------------------------------------------------------
    Private Function LoadTeam() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim udtTeam As udtTeamType = New udtTeamType

            ' Which team do we edit?
            udtTeam.intTeamID = f_intTeamID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it
            blnResult = GetTeamInformationFromDatabase(udtTeam)

            ' Did it work?
            If blnResult = True Then

                ' Yes
                txtTeam.Text = udtTeam.strTeam
                txtMascot.Text = udtTeam.strMascot

                ' Set focus to Team name and select existing text
                txtTeam.Focus()
                txtTeam.SelectAll()

                ' Clear dirty flag
                SetDirty(False)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: txtField_TextChanged
    ' Abstract: Set the dirty flag if any field changes
    ' -------------------------------------------------------------------------
    Private Sub txtField_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                     Handles txtTeam.TextChanged, _
                                             txtMascot.TextChanged


        Try

            SetDirty(True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: If the data is good then save the changes
    ' -------------------------------------------------------------------------
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

        Try

            ' Is the data OK?
            If IsValidData() = True Then

                ' Yes, save
                If SaveData() = True Then

                    ' If the save was successful then ...

                    ' Success
                    f_blnResult = True

                    ' Hide
                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Validate the data on the form before committing changes to the database.
    ' -------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True   ' Assume good data

        Try

            Dim strErrorMessage As String = "Please correct the following errors:" & vbNewLine

            ' Trim any spaces
            TrimAllFormTextBoxes(Me)

            ' Is the team name blank?
            If txtTeam.Text = "" Then

                strErrorMessage = strErrorMessage & "-Team cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Is the mascot blank?
            If txtMascot.Text = "" Then

                strErrorMessage = strErrorMessage & "-Mascot cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Bad data?
            If blnIsValidData = False Then

                ' Yes, tell the user what they did wrong
                MessageBox.Show(strErrorMessage, Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function


    ' -------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Save the Team to the database
    ' -------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim udtTeam As udtTeamType

            ' Get values from form
            udtTeam.intTeamID = f_intTeamID
            udtTeam.strTeam = txtTeam.Text
            udtTeam.strMascot = txtMascot.Text

            ' We are busy
            SetBusyCursor(Me, True)

            ' Update the database
            blnResult = EditTeamInDatabase(udtTeam)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form without saving changes
    ' -------------------------------------------------------------------------
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Try

            Dim drConfirm As DialogResult

            ' Has the user made changes?
            If GetDirty() = True Then

                ' Yes, confirm they want to cancel
                drConfirm = MessageBox.Show("Are you sure?", "Cancel " & Me.Text, _
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Are they sure?
                If drConfirm = DialogResult.Yes Then

                    ' Close the form
                    Me.Hide()

                End If

            Else

                ' No changes so just close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetDirty
    ' Abstract: Have changes been made to the form?
    ' -------------------------------------------------------------------------
    Public Function GetDirty() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnDirty

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetDirty
    ' Abstract: A change has been made to the form
    ' -------------------------------------------------------------------------
    Public Sub SetDirty(ByVal blnDirty As Boolean)

        Try

            f_blnDirty = blnDirty

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' -------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: GetNewTeamInformation
    ' Abstract: Get the new Team information
    ' -------------------------------------------------------------------------
    Public Function GetNewTeamInformation() As CListItem

        Dim clsTeam As New CListItem

        Try

            clsTeam.SetID(f_intTeamID)
            clsTeam.SetName(txtTeam.Text)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return clsTeam

    End Function


End Class


