' -------------------------------------------------------------------------
'   Form: FAddTeam
'   Purpose: Allow the user to add a team
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FAddTeam

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------
    Private f_blnLoaded As Boolean
    Private f_blnDirty As Boolean       ' Have any changes been made
    Private f_blnResult As Boolean      ' Don't use DialogResult since it triggers a cascade close
    Private f_intTeamID As Integer



    ' -------------------------------------------------------------------------
    ' Name: FAddTeam_Activated
    ' Abstract: Do any initialization
    ' -------------------------------------------------------------------------
    Private Sub FAddTeam_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated

        Try

            ' Have we loaded?
            If f_blnLoaded = False Then

                ' No but now we have
                f_blnLoaded = True

                ' Not successful
                f_blnResult = False

                ' We are busy
                SetBusyCursor(Me, True)

                ' Clear dirty flag
                SetDirty(False)

                ' Set focus to team name 
                txtTeam.Focus()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: txtField_TextChanged
    ' Abstract: Set the dirty flag if any field changes
    '           Confirm canceling any changes
    ' -------------------------------------------------------------------------
    Private Sub txtField_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
                                     Handles txtTeam.TextChanged, _
                                             txtMascot.TextChanged

        Try

            SetDirty(True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: If the data is good then save the changes
    ' -------------------------------------------------------------------------
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

        Try

            ' Is the data OK?
            If IsValidData() = True Then

                ' Yes, save
                If SaveData() = True Then

                    ' If the save was successful then ...

                    ' Success
                    f_blnResult = True

                    ' Hide
                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Validate the data on the form before adding to the database.
    ' -------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True   ' Assume good data

        Try

            Dim strErrorMessage As String = "Please correct the following errors:" & vbNewLine

            ' Trim any spaces
            TrimAllFormTextBoxes(Me)

            ' Is the team name blank?
            If txtTeam.Text = "" Then

                strErrorMessage = strErrorMessage & "-Team cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Is the mascot blank?
            If txtMascot.Text = "" Then

                strErrorMessage = strErrorMessage & "-Mascot cannot be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Bad data?
            If blnIsValidData = False Then

                ' Yes, tell the user what they did wrong
                MessageBox.Show(strErrorMessage, Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function


    ' -------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Save the team to the database
    ' -------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim udtTeam As udtTeamType

            ' Get values from form
            udtTeam.intTeamID = 0                   ' Will be returned from DB ca
            udtTeam.strTeam = txtTeam.Text
            udtTeam.strMascot = txtMascot.Text

            ' We are busy
            SetBusyCursor(Me, True)

            ' Add to the database
            blnResult = AddTeamToDatabase(udtTeam)

            ' Did it work?
            If blnResult = True Then

                ' Yes, save the ID
                f_intTeamID = udtTeam.intTeamID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form without saving changes
    ' -------------------------------------------------------------------------
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Try

            Dim drConfirm As DialogResult

            ' Has the user made changes?
            If GetDirty() = True Then

                ' Yes, confirm they want to cancel
                drConfirm = MessageBox.Show("Are you sure?", "Cancel " & Me.Text, _
                                             MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Are they sure?
                If drConfirm = DialogResult.Yes Then

                    ' Close the form
                    Me.Hide()

                End If

            Else

                ' No changes so just close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetDirty
    ' Abstract: Have changes been made to the form?
    ' -------------------------------------------------------------------------
    Private Function GetDirty() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnDirty

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetDirty
    ' Abstract: A change has been made to the form
    ' -------------------------------------------------------------------------
    Private Sub SetDirty(ByVal blnDirty As Boolean)

        Try

            f_blnDirty = blnDirty

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' -------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function


    ' -------------------------------------------------------------------------
    ' Name: GetNewTeamInformation
    ' Abstract: Get the new team information
    ' -------------------------------------------------------------------------
    Public Function GetNewTeamInformation() As CListItem

        Dim clsTeam As CListItem = Nothing

        Try

            clsTeam = New CListItem(f_intTeamID, txtTeam.Text)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return clsTeam

    End Function

End Class
