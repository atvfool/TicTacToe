' -------------------------------------------------------------------------
'   Form: FManageTeams
'   Purpose: Allow the user to manage (add/edit/delete) a team
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Form options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FManageTeams

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------



    ' -------------------------------------------------------------------------
    ' Name: FManageTeams_Load
    ' Abstract: Do any initialization
    ' -------------------------------------------------------------------------
    Private Sub FManageTeams_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            ' This may take a while
            Me.Show()

            LoadTeamList()

            ' Set the focus
            lstTeams.Focus()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: LoadTeamList
    ' Abstract: Load the Team list
    ' -------------------------------------------------------------------------
    Private Sub LoadTeamList(Optional ByVal intDefaultTeamID As Integer = 0)

        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveTeams"

            Else

                strSourceTable = "VInactiveTeams"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            LoadListBoxFromDatabase(strSourceTable, _
                                    "intTeamID", _
                                    "strTeam", _
                                    lstTeams)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a team
    ' -------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click

        Try

            AddTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: AddTeam
    ' Abstract: Add a team
    ' -------------------------------------------------------------------------
    Private Sub AddTeam()

        Try

            Dim frmAddTeam As FAddTeam
            Dim clsTeam As CListItem
            Dim intListIndex As Integer

            ' Create form
            frmAddTeam = New FAddTeam

            ' Show it
            frmAddTeam.ShowDialog(Me)

            ' Was the Add successful?
            If frmAddTeam.GetResult() = True Then

                ' Get the new team information
                clsTeam = frmAddTeam.GetNewTeamInformation()

                ' Add the item to the list and select it
                intListIndex = lstTeams.Items.Add(clsTeam)
                lstTeams.SelectedIndex = intListIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: lstTeams_DblClick
    ' Abstract: Same as clicking edit
    ' -------------------------------------------------------------------------
    Private Sub lstTeams_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTeams.DoubleClick

        Try

            ' Same as clicking edit
            EditTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the currently selected team
    ' -------------------------------------------------------------------------
    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click

        Try

            EditTeam()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: EditTeam
    ' Abstract: Edit the currently selected team
    ' -------------------------------------------------------------------------
    Private Sub EditTeam()

        Try

            Dim frmEditTeam As FEditTeam

            Dim intSelectedTeamID As Integer
            Dim clsTeam As CListItem
            Dim intListIndex As Integer

            ' Get the selected team ID
            intSelectedTeamID = GetSelectedListItemID(lstTeams)

            ' Is a team selected?
            If intSelectedTeamID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a team to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, create form
                frmEditTeam = New FEditTeam

                ' Yes, set the form values
                frmEditTeam.SetFormValues(intSelectedTeamID)

                ' Show it
                frmEditTeam.ShowDialog(Me)

                ' Was the Add successful?
                If frmEditTeam.GetResult() = True Then

                    ' Get the new team values
                    clsTeam = frmEditTeam.GetNewTeamInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstTeams.Items.RemoveAt(lstTeams.SelectedIndex)
                    intListIndex = lstTeams.Items.Add(clsTeam)
                    lstTeams.SelectedIndex = intListIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the currently selected team.
    ' -------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click

        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteTeam()

            Else

                ' No, undelete
                UndeleteTeam()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: DeleteTeam
    ' Abstract: Delete the currently selected team.
    ' -------------------------------------------------------------------------
    Private Sub DeleteTeam()

        Try

            Dim intSelectedTeamID As Integer
            Dim strSelectedTeamName As String
            Dim intSelectedTeamIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Get the selected team ID
            intSelectedTeamID = GetSelectedListItemID(lstTeams)

            ' Is a team selected?
            If intSelectedTeamID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a team to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the team name and list index
                strSelectedTeamName = lstTeams.Items.Item(lstTeams.SelectedIndex).GetName
                intSelectedTeamIndex = lstTeams.SelectedIndex

                ' Yes, confirm they want to delete
                drConfirm = MessageBox.Show("Are you sure?", _
                                             "Delete Team: " & strSelectedTeamName, _
                                             MessageBoxButtons.YesNo, _
                                             MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the team 
                    blnResult = DeleteTeamFromDatabase(intSelectedTeamID)

                    ' Was the delete successful?
                    If blnResult = True Then

                        ' Yes, remove the team from the list
                        lstTeams.Items.RemoveAt(intSelectedTeamIndex)

                        ' Select the next team in the list
                        HighlightNextItemInList(lstTeams, intSelectedTeamIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: UndeleteTeam
    ' Abstract: Undelete the currently selected team.
    ' -------------------------------------------------------------------------
    Private Sub UndeleteTeam()

        Try

            Dim intSelectedTeamID As Integer
            Dim intSelectedTeamIndex As Integer
            Dim blnResult As Boolean

            ' Get the selected team ID
            intSelectedTeamID = GetSelectedListItemID(lstTeams)

            ' Is a team selected?
            If intSelectedTeamID < 1 Then

                ' No, warn the user
                MessageBox.Show("You must select a team to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the list index
                intSelectedTeamIndex = lstTeams.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the team 
                blnResult = UndeleteTeamFromDatabase(intSelectedTeamID)

                ' Was the undelete successful?
                If blnResult = True Then

                    ' Yes, remove the team from the list
                    lstTeams.Items.RemoveAt(intSelectedTeamIndex)

                    ' Select the next team in the list
                    HighlightNextItemInList(lstTeams, intSelectedTeamIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active and inactive teams
    ' -------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowDeleted.CheckedChanged

        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

           LoadTeamList

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form
    ' -------------------------------------------------------------------------
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Try

            ' Goodbye cruel world
            Me.Hide()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

End Class
