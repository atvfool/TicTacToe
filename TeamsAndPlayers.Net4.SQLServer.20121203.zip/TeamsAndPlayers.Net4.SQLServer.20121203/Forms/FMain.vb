' -------------------------------------------------------------------------
'   Form: FMain
'   Author: Patrick Callahan
'   Abstract: This program manages teams, players and team players
'
'   Revision        Owner   Changes:
'1  2001/04/16      P.C.    Created.
'2  2003/04/17      P.C.    Updated to .Net
'3  2007/08/13      P.C.    Updated to .Net 2.0
'4  2012/06/06      P.C.    Updated to .Net 4.0 and Windows 7
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
'  Options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
'  Imports
' -------------------------------------------------------------------------


Public Class FMain

    ' -------------------------------------------------------------------------
    ' Form Variables
    ' -------------------------------------------------------------------------



    ' -------------------------------------------------------------------------
    ' Name: FMain_Load
    ' Abstract: Called when the form is load.  Perform some initialization.
    ' -------------------------------------------------------------------------
    Private Sub FMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            ' Show the form because this function takes a while
            ' There may be problems connecting to the DB.  Users won't know what's going on if they 
            ' can't see anything
            Me.Show()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Allow only 1 instance of the application to run
            If CheckForPreviousApplicationInstance() = True Then Me.Close()

            ' Connect to the database.  End if connection fails.
            If OpenDatabaseConnection() = False Then Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

            ' End program
            End

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: FMain_FormClosing
    ' Abstract: Goodbye cruel world.  Clean up.
    ' -------------------------------------------------------------------------
    Private Sub FMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Try

            CloseDatabaseConnection()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


#Region "Manage Teams"

    ' -------------------------------------------------------------------------
    ' Name: mnuManageTeams_Click
    ' Abstract: Display the manage teams form
    ' -------------------------------------------------------------------------
    Private Sub mnuManageTeams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuManageTeams.Click

        Try

            ManageTeams()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnManageTeams_Click
    ' Abstract: Display the manage teams form
    ' -------------------------------------------------------------------------
    Private Sub btnManageTeams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManageTeams.Click

        Try

            ManageTeams()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: ManageTeams
    ' Abstract: Display the manage teams form
    ' -------------------------------------------------------------------------
    Private Sub ManageTeams()

        Try

            Dim frmManageTeams As FManageTeams

            ' Create instance
            frmManageTeams = New FManageTeams

            frmManageTeams.ShowDialog(Me)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

#End Region

#Region "Assign TeamPlayers"

    ' -------------------------------------------------------------------------
    ' Name: mnuAssignTeamPlayers_Click
    ' Abstract: Display the manage TeamPlayers form
    ' -------------------------------------------------------------------------
    Private Sub mnuAssignTeamPlayers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAssignTeamPlayers.Click

        Try

            AssignTeamPlayers()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnAssignTeamPlayers_Click
    ' Abstract: Display the manage TeamPlayers form
    ' -------------------------------------------------------------------------
    Private Sub btnAssignTeamPlayers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAssignTeamPlayers.Click

        Try

            AssignTeamPlayers()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: AssignTeamPlayers
    ' Abstract: Display the manage TeamPlayers form
    ' -------------------------------------------------------------------------
    Private Sub AssignTeamPlayers()

        Try

            Dim frmAssignTeamPlayers As FAssignTeamPlayers

            ' Create instance
            frmAssignTeamPlayers = New FAssignTeamPlayers

            frmAssignTeamPlayers.ShowDialog(Me)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

#End Region

#Region "Manage Players"

    ' -------------------------------------------------------------------------
    ' Name: mnuManagePlayersV1_Click
    ' Abstract: Display the manage Players form
    ' -------------------------------------------------------------------------
    Private Sub mnuManagePlayersV1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuManagePlayersV1.Click

        Try

            ManagePlayersV1()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnManagePlayersV1_Click
    ' Abstract: Display the manage Players form
    ' -------------------------------------------------------------------------
    Private Sub btnManagePlayersV1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManagePlayersV1.Click

        Try

            ManagePlayersV1()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: ManagePlayersV1
    ' Abstract: Display the manage Players form
    '
    '   Version #1 has:
    '       - Separate Add and Edit Forms
    '       - A listBOX to display player information on the manage forms
    ' -------------------------------------------------------------------------
    Private Sub ManagePlayersV1()

        Try

            Dim frmManagePlayers As FManagePlayersV1

            ' Create instance
            frmManagePlayers = New FManagePlayersV1

            frmManagePlayers.ShowDialog(Me)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: mnuManagePlayersV2_Click
    ' Abstract: Display the manage Players form
    ' -------------------------------------------------------------------------
    Private Sub mnuManagePlayersV2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuManagePlayersV2.Click

        Try

            ManagePlayersV2()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: btnManagePlayersV2_Click
    ' Abstract: Display the manage Players form
    ' -------------------------------------------------------------------------
    Private Sub btnManagePlayersV2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManagePlayersV2.Click

        Try

            ManagePlayersV2()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: ManagePlayersV2
    ' Abstract: Display the manage Players form
    '
    '   Version #2 has:
    '       - Combined Add and Edit Forms since the code is so similar
    '       - A listVIEW to display player information on the manage forms
    ' -------------------------------------------------------------------------
    Private Sub ManagePlayersV2()

        Try

            Dim frmManagePlayers As FManagePlayersV2

            ' Create instance
            frmManagePlayers = New FManagePlayersV2

            frmManagePlayers.ShowDialog(Me)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub


#End Region

End Class
