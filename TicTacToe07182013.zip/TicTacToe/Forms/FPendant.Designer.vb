﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FPendant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnGoToSoftHome = New System.Windows.Forms.Button()
        Me.btnAboveBoard = New System.Windows.Forms.Button()
        Me.btnWristLeft = New System.Windows.Forms.Button()
        Me.btnTurretLeft = New System.Windows.Forms.Button()
        Me.btnWristOut = New System.Windows.Forms.Button()
        Me.btnWristRight = New System.Windows.Forms.Button()
        Me.btnWristIn = New System.Windows.Forms.Button()
        Me.grWristControls = New System.Windows.Forms.GroupBox()
        Me.btnTurretRight = New System.Windows.Forms.Button()
        Me.grpTurret = New System.Windows.Forms.GroupBox()
        Me.btnHandOpen = New System.Windows.Forms.Button()
        Me.btnHandClose = New System.Windows.Forms.Button()
        Me.grpHand = New System.Windows.Forms.GroupBox()
        Me.grpElbow = New System.Windows.Forms.GroupBox()
        Me.btnElbowOut = New System.Windows.Forms.Button()
        Me.btnElbowIn = New System.Windows.Forms.Button()
        Me.grpShoulder = New System.Windows.Forms.GroupBox()
        Me.btnShoulderOut = New System.Windows.Forms.Button()
        Me.btnShoulderIn = New System.Windows.Forms.Button()
        Me.grpTicTacToeGrid = New System.Windows.Forms.GroupBox()
        Me.btnPlace2 = New System.Windows.Forms.Button()
        Me.btnPlace3 = New System.Windows.Forms.Button()
        Me.btnPlace4 = New System.Windows.Forms.Button()
        Me.btnPlace5 = New System.Windows.Forms.Button()
        Me.btnPlace6 = New System.Windows.Forms.Button()
        Me.btnPlace7 = New System.Windows.Forms.Button()
        Me.btnPlace8 = New System.Windows.Forms.Button()
        Me.btnPlace9 = New System.Windows.Forms.Button()
        Me.btnPlace1 = New System.Windows.Forms.Button()
        Me.grpTicTacToeTray = New System.Windows.Forms.GroupBox()
        Me.btnX4 = New System.Windows.Forms.Button()
        Me.btnO4 = New System.Windows.Forms.Button()
        Me.btnO1 = New System.Windows.Forms.Button()
        Me.btnX2 = New System.Windows.Forms.Button()
        Me.btnO2 = New System.Windows.Forms.Button()
        Me.btnX3 = New System.Windows.Forms.Button()
        Me.btnO3 = New System.Windows.Forms.Button()
        Me.btnX5 = New System.Windows.Forms.Button()
        Me.btnO5 = New System.Windows.Forms.Button()
        Me.btnX1 = New System.Windows.Forms.Button()
        Me.btnTray = New System.Windows.Forms.Button()
        Me.btnShowOffsets = New System.Windows.Forms.Button()
        Me.btnReturnValueFromRobot = New System.Windows.Forms.Button()
        Me.grWristControls.SuspendLayout()
        Me.grpTurret.SuspendLayout()
        Me.grpHand.SuspendLayout()
        Me.grpElbow.SuspendLayout()
        Me.grpShoulder.SuspendLayout()
        Me.grpTicTacToeGrid.SuspendLayout()
        Me.grpTicTacToeTray.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnGoToSoftHome
        '
        Me.btnGoToSoftHome.Location = New System.Drawing.Point(12, 13)
        Me.btnGoToSoftHome.Name = "btnGoToSoftHome"
        Me.btnGoToSoftHome.Size = New System.Drawing.Size(108, 52)
        Me.btnGoToSoftHome.TabIndex = 0
        Me.btnGoToSoftHome.Text = "Go To Soft Home"
        Me.btnGoToSoftHome.UseVisualStyleBackColor = True
        '
        'btnAboveBoard
        '
        Me.btnAboveBoard.Location = New System.Drawing.Point(12, 71)
        Me.btnAboveBoard.Name = "btnAboveBoard"
        Me.btnAboveBoard.Size = New System.Drawing.Size(108, 52)
        Me.btnAboveBoard.TabIndex = 1
        Me.btnAboveBoard.Text = "Above Board"
        Me.btnAboveBoard.UseVisualStyleBackColor = True
        '
        'btnWristLeft
        '
        Me.btnWristLeft.Location = New System.Drawing.Point(6, 40)
        Me.btnWristLeft.Name = "btnWristLeft"
        Me.btnWristLeft.Size = New System.Drawing.Size(75, 23)
        Me.btnWristLeft.TabIndex = 2
        Me.btnWristLeft.Text = "Wrist Left"
        Me.btnWristLeft.UseVisualStyleBackColor = True
        '
        'btnTurretLeft
        '
        Me.btnTurretLeft.Location = New System.Drawing.Point(19, 40)
        Me.btnTurretLeft.Name = "btnTurretLeft"
        Me.btnTurretLeft.Size = New System.Drawing.Size(75, 23)
        Me.btnTurretLeft.TabIndex = 3
        Me.btnTurretLeft.Text = "Turret Left"
        Me.btnTurretLeft.UseVisualStyleBackColor = True
        '
        'btnWristOut
        '
        Me.btnWristOut.Location = New System.Drawing.Point(62, 11)
        Me.btnWristOut.Name = "btnWristOut"
        Me.btnWristOut.Size = New System.Drawing.Size(75, 23)
        Me.btnWristOut.TabIndex = 4
        Me.btnWristOut.Text = "Wrist Out"
        Me.btnWristOut.UseVisualStyleBackColor = True
        '
        'btnWristRight
        '
        Me.btnWristRight.Location = New System.Drawing.Point(119, 40)
        Me.btnWristRight.Name = "btnWristRight"
        Me.btnWristRight.Size = New System.Drawing.Size(75, 23)
        Me.btnWristRight.TabIndex = 5
        Me.btnWristRight.Text = "Wrist Right"
        Me.btnWristRight.UseVisualStyleBackColor = True
        '
        'btnWristIn
        '
        Me.btnWristIn.Location = New System.Drawing.Point(62, 69)
        Me.btnWristIn.Name = "btnWristIn"
        Me.btnWristIn.Size = New System.Drawing.Size(75, 23)
        Me.btnWristIn.TabIndex = 6
        Me.btnWristIn.Text = "Wrist In"
        Me.btnWristIn.UseVisualStyleBackColor = True
        '
        'grWristControls
        '
        Me.grWristControls.Controls.Add(Me.btnWristLeft)
        Me.grWristControls.Controls.Add(Me.btnWristIn)
        Me.grWristControls.Controls.Add(Me.btnWristOut)
        Me.grWristControls.Controls.Add(Me.btnWristRight)
        Me.grWristControls.Location = New System.Drawing.Point(126, 13)
        Me.grWristControls.Name = "grWristControls"
        Me.grWristControls.Size = New System.Drawing.Size(200, 100)
        Me.grWristControls.TabIndex = 7
        Me.grWristControls.TabStop = False
        Me.grWristControls.Text = "Wrist Controls"
        '
        'btnTurretRight
        '
        Me.btnTurretRight.Location = New System.Drawing.Point(100, 40)
        Me.btnTurretRight.Name = "btnTurretRight"
        Me.btnTurretRight.Size = New System.Drawing.Size(75, 23)
        Me.btnTurretRight.TabIndex = 8
        Me.btnTurretRight.Text = "Turret Right"
        Me.btnTurretRight.UseVisualStyleBackColor = True
        '
        'grpTurret
        '
        Me.grpTurret.Controls.Add(Me.btnTurretRight)
        Me.grpTurret.Controls.Add(Me.btnTurretLeft)
        Me.grpTurret.Location = New System.Drawing.Point(332, 13)
        Me.grpTurret.Name = "grpTurret"
        Me.grpTurret.Size = New System.Drawing.Size(200, 100)
        Me.grpTurret.TabIndex = 9
        Me.grpTurret.TabStop = False
        Me.grpTurret.Text = "Turret"
        '
        'btnHandOpen
        '
        Me.btnHandOpen.Location = New System.Drawing.Point(19, 41)
        Me.btnHandOpen.Name = "btnHandOpen"
        Me.btnHandOpen.Size = New System.Drawing.Size(75, 23)
        Me.btnHandOpen.TabIndex = 10
        Me.btnHandOpen.Text = "Hand Open"
        Me.btnHandOpen.UseVisualStyleBackColor = True
        '
        'btnHandClose
        '
        Me.btnHandClose.Location = New System.Drawing.Point(100, 41)
        Me.btnHandClose.Name = "btnHandClose"
        Me.btnHandClose.Size = New System.Drawing.Size(75, 23)
        Me.btnHandClose.TabIndex = 11
        Me.btnHandClose.Text = "Hand Close"
        Me.btnHandClose.UseVisualStyleBackColor = True
        '
        'grpHand
        '
        Me.grpHand.Controls.Add(Me.btnHandOpen)
        Me.grpHand.Controls.Add(Me.btnHandClose)
        Me.grpHand.Location = New System.Drawing.Point(126, 119)
        Me.grpHand.Name = "grpHand"
        Me.grpHand.Size = New System.Drawing.Size(200, 100)
        Me.grpHand.TabIndex = 12
        Me.grpHand.TabStop = False
        Me.grpHand.Text = "Hand"
        '
        'grpElbow
        '
        Me.grpElbow.Controls.Add(Me.btnElbowOut)
        Me.grpElbow.Controls.Add(Me.btnElbowIn)
        Me.grpElbow.Location = New System.Drawing.Point(332, 119)
        Me.grpElbow.Name = "grpElbow"
        Me.grpElbow.Size = New System.Drawing.Size(200, 100)
        Me.grpElbow.TabIndex = 13
        Me.grpElbow.TabStop = False
        Me.grpElbow.Text = "Elbow"
        '
        'btnElbowOut
        '
        Me.btnElbowOut.Location = New System.Drawing.Point(100, 40)
        Me.btnElbowOut.Name = "btnElbowOut"
        Me.btnElbowOut.Size = New System.Drawing.Size(75, 23)
        Me.btnElbowOut.TabIndex = 8
        Me.btnElbowOut.Text = "Elbow Out"
        Me.btnElbowOut.UseVisualStyleBackColor = True
        '
        'btnElbowIn
        '
        Me.btnElbowIn.Location = New System.Drawing.Point(19, 40)
        Me.btnElbowIn.Name = "btnElbowIn"
        Me.btnElbowIn.Size = New System.Drawing.Size(75, 23)
        Me.btnElbowIn.TabIndex = 3
        Me.btnElbowIn.Text = "Elbow In"
        Me.btnElbowIn.UseVisualStyleBackColor = True
        '
        'grpShoulder
        '
        Me.grpShoulder.Controls.Add(Me.btnShoulderOut)
        Me.grpShoulder.Controls.Add(Me.btnShoulderIn)
        Me.grpShoulder.Location = New System.Drawing.Point(126, 225)
        Me.grpShoulder.Name = "grpShoulder"
        Me.grpShoulder.Size = New System.Drawing.Size(200, 100)
        Me.grpShoulder.TabIndex = 14
        Me.grpShoulder.TabStop = False
        Me.grpShoulder.Text = "Shoulder"
        '
        'btnShoulderOut
        '
        Me.btnShoulderOut.Location = New System.Drawing.Point(100, 40)
        Me.btnShoulderOut.Name = "btnShoulderOut"
        Me.btnShoulderOut.Size = New System.Drawing.Size(82, 23)
        Me.btnShoulderOut.TabIndex = 8
        Me.btnShoulderOut.Text = "Shoulder Out"
        Me.btnShoulderOut.UseVisualStyleBackColor = True
        '
        'btnShoulderIn
        '
        Me.btnShoulderIn.Location = New System.Drawing.Point(19, 40)
        Me.btnShoulderIn.Name = "btnShoulderIn"
        Me.btnShoulderIn.Size = New System.Drawing.Size(75, 23)
        Me.btnShoulderIn.TabIndex = 3
        Me.btnShoulderIn.Text = "Shoulder In"
        Me.btnShoulderIn.UseVisualStyleBackColor = True
        '
        'grpTicTacToeGrid
        '
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace2)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace3)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace4)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace5)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace6)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace7)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace8)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace9)
        Me.grpTicTacToeGrid.Controls.Add(Me.btnPlace1)
        Me.grpTicTacToeGrid.Location = New System.Drawing.Point(538, 13)
        Me.grpTicTacToeGrid.Name = "grpTicTacToeGrid"
        Me.grpTicTacToeGrid.Size = New System.Drawing.Size(251, 110)
        Me.grpTicTacToeGrid.TabIndex = 15
        Me.grpTicTacToeGrid.TabStop = False
        Me.grpTicTacToeGrid.Text = "Tic Tac Toe "
        '
        'btnPlace2
        '
        Me.btnPlace2.Location = New System.Drawing.Point(88, 19)
        Me.btnPlace2.Name = "btnPlace2"
        Me.btnPlace2.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace2.TabIndex = 8
        Me.btnPlace2.Text = "Place 2"
        Me.btnPlace2.UseVisualStyleBackColor = True
        '
        'btnPlace3
        '
        Me.btnPlace3.Location = New System.Drawing.Point(169, 19)
        Me.btnPlace3.Name = "btnPlace3"
        Me.btnPlace3.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace3.TabIndex = 7
        Me.btnPlace3.Text = "Place 3"
        Me.btnPlace3.UseVisualStyleBackColor = True
        '
        'btnPlace4
        '
        Me.btnPlace4.Location = New System.Drawing.Point(6, 48)
        Me.btnPlace4.Name = "btnPlace4"
        Me.btnPlace4.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace4.TabIndex = 6
        Me.btnPlace4.Text = "Place 4"
        Me.btnPlace4.UseVisualStyleBackColor = True
        '
        'btnPlace5
        '
        Me.btnPlace5.Location = New System.Drawing.Point(88, 48)
        Me.btnPlace5.Name = "btnPlace5"
        Me.btnPlace5.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace5.TabIndex = 5
        Me.btnPlace5.Text = "Place 5"
        Me.btnPlace5.UseVisualStyleBackColor = True
        '
        'btnPlace6
        '
        Me.btnPlace6.Location = New System.Drawing.Point(169, 48)
        Me.btnPlace6.Name = "btnPlace6"
        Me.btnPlace6.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace6.TabIndex = 4
        Me.btnPlace6.Text = "Place 6"
        Me.btnPlace6.UseVisualStyleBackColor = True
        '
        'btnPlace7
        '
        Me.btnPlace7.Location = New System.Drawing.Point(7, 77)
        Me.btnPlace7.Name = "btnPlace7"
        Me.btnPlace7.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace7.TabIndex = 3
        Me.btnPlace7.Text = "Place 7"
        Me.btnPlace7.UseVisualStyleBackColor = True
        '
        'btnPlace8
        '
        Me.btnPlace8.Location = New System.Drawing.Point(88, 77)
        Me.btnPlace8.Name = "btnPlace8"
        Me.btnPlace8.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace8.TabIndex = 2
        Me.btnPlace8.Text = "Place 8"
        Me.btnPlace8.UseVisualStyleBackColor = True
        '
        'btnPlace9
        '
        Me.btnPlace9.Location = New System.Drawing.Point(169, 77)
        Me.btnPlace9.Name = "btnPlace9"
        Me.btnPlace9.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace9.TabIndex = 1
        Me.btnPlace9.Text = "Place 9"
        Me.btnPlace9.UseVisualStyleBackColor = True
        '
        'btnPlace1
        '
        Me.btnPlace1.Location = New System.Drawing.Point(6, 19)
        Me.btnPlace1.Name = "btnPlace1"
        Me.btnPlace1.Size = New System.Drawing.Size(75, 23)
        Me.btnPlace1.TabIndex = 0
        Me.btnPlace1.Text = "Place 1"
        Me.btnPlace1.UseVisualStyleBackColor = True
        '
        'grpTicTacToeTray
        '
        Me.grpTicTacToeTray.Controls.Add(Me.btnX4)
        Me.grpTicTacToeTray.Controls.Add(Me.btnO4)
        Me.grpTicTacToeTray.Controls.Add(Me.btnO1)
        Me.grpTicTacToeTray.Controls.Add(Me.btnX2)
        Me.grpTicTacToeTray.Controls.Add(Me.btnO2)
        Me.grpTicTacToeTray.Controls.Add(Me.btnX3)
        Me.grpTicTacToeTray.Controls.Add(Me.btnO3)
        Me.grpTicTacToeTray.Controls.Add(Me.btnX5)
        Me.grpTicTacToeTray.Controls.Add(Me.btnO5)
        Me.grpTicTacToeTray.Controls.Add(Me.btnX1)
        Me.grpTicTacToeTray.Location = New System.Drawing.Point(538, 129)
        Me.grpTicTacToeTray.Name = "grpTicTacToeTray"
        Me.grpTicTacToeTray.Size = New System.Drawing.Size(251, 217)
        Me.grpTicTacToeTray.TabIndex = 16
        Me.grpTicTacToeTray.TabStop = False
        Me.grpTicTacToeTray.Text = "Tic Tac Toe  Tray"
        '
        'btnX4
        '
        Me.btnX4.Location = New System.Drawing.Point(7, 106)
        Me.btnX4.Name = "btnX4"
        Me.btnX4.Size = New System.Drawing.Size(75, 23)
        Me.btnX4.TabIndex = 10
        Me.btnX4.Text = "X 4"
        Me.btnX4.UseVisualStyleBackColor = True
        '
        'btnO4
        '
        Me.btnO4.Location = New System.Drawing.Point(88, 106)
        Me.btnO4.Name = "btnO4"
        Me.btnO4.Size = New System.Drawing.Size(75, 23)
        Me.btnO4.TabIndex = 9
        Me.btnO4.Text = "O 4"
        Me.btnO4.UseVisualStyleBackColor = True
        '
        'btnO1
        '
        Me.btnO1.Location = New System.Drawing.Point(88, 19)
        Me.btnO1.Name = "btnO1"
        Me.btnO1.Size = New System.Drawing.Size(75, 23)
        Me.btnO1.TabIndex = 8
        Me.btnO1.Text = "O 1"
        Me.btnO1.UseVisualStyleBackColor = True
        '
        'btnX2
        '
        Me.btnX2.Location = New System.Drawing.Point(6, 48)
        Me.btnX2.Name = "btnX2"
        Me.btnX2.Size = New System.Drawing.Size(75, 23)
        Me.btnX2.TabIndex = 7
        Me.btnX2.Text = "X 2"
        Me.btnX2.UseVisualStyleBackColor = True
        '
        'btnO2
        '
        Me.btnO2.Location = New System.Drawing.Point(88, 48)
        Me.btnO2.Name = "btnO2"
        Me.btnO2.Size = New System.Drawing.Size(75, 23)
        Me.btnO2.TabIndex = 6
        Me.btnO2.Text = "O 2"
        Me.btnO2.UseVisualStyleBackColor = True
        '
        'btnX3
        '
        Me.btnX3.Location = New System.Drawing.Point(6, 77)
        Me.btnX3.Name = "btnX3"
        Me.btnX3.Size = New System.Drawing.Size(75, 23)
        Me.btnX3.TabIndex = 5
        Me.btnX3.Text = "X 3"
        Me.btnX3.UseVisualStyleBackColor = True
        '
        'btnO3
        '
        Me.btnO3.Location = New System.Drawing.Point(88, 77)
        Me.btnO3.Name = "btnO3"
        Me.btnO3.Size = New System.Drawing.Size(75, 23)
        Me.btnO3.TabIndex = 4
        Me.btnO3.Text = "O 3"
        Me.btnO3.UseVisualStyleBackColor = True
        '
        'btnX5
        '
        Me.btnX5.Location = New System.Drawing.Point(7, 135)
        Me.btnX5.Name = "btnX5"
        Me.btnX5.Size = New System.Drawing.Size(75, 23)
        Me.btnX5.TabIndex = 3
        Me.btnX5.Text = "X 5"
        Me.btnX5.UseVisualStyleBackColor = True
        '
        'btnO5
        '
        Me.btnO5.Location = New System.Drawing.Point(88, 135)
        Me.btnO5.Name = "btnO5"
        Me.btnO5.Size = New System.Drawing.Size(75, 23)
        Me.btnO5.TabIndex = 2
        Me.btnO5.Text = "O 5"
        Me.btnO5.UseVisualStyleBackColor = True
        '
        'btnX1
        '
        Me.btnX1.Location = New System.Drawing.Point(6, 19)
        Me.btnX1.Name = "btnX1"
        Me.btnX1.Size = New System.Drawing.Size(75, 23)
        Me.btnX1.TabIndex = 0
        Me.btnX1.Text = "X 1"
        Me.btnX1.UseVisualStyleBackColor = True
        '
        'btnTray
        '
        Me.btnTray.Location = New System.Drawing.Point(12, 129)
        Me.btnTray.Name = "btnTray"
        Me.btnTray.Size = New System.Drawing.Size(108, 52)
        Me.btnTray.TabIndex = 17
        Me.btnTray.Text = "Above Tray"
        Me.btnTray.UseVisualStyleBackColor = True
        '
        'btnShowOffsets
        '
        Me.btnShowOffsets.Location = New System.Drawing.Point(12, 187)
        Me.btnShowOffsets.Name = "btnShowOffsets"
        Me.btnShowOffsets.Size = New System.Drawing.Size(108, 52)
        Me.btnShowOffsets.TabIndex = 18
        Me.btnShowOffsets.Text = "Show Offsets"
        Me.btnShowOffsets.UseVisualStyleBackColor = True
        '
        'btnReturnValueFromRobot
        '
        Me.btnReturnValueFromRobot.Location = New System.Drawing.Point(12, 245)
        Me.btnReturnValueFromRobot.Name = "btnReturnValueFromRobot"
        Me.btnReturnValueFromRobot.Size = New System.Drawing.Size(108, 43)
        Me.btnReturnValueFromRobot.TabIndex = 19
        Me.btnReturnValueFromRobot.Text = "Return Value From Robot"
        Me.btnReturnValueFromRobot.UseVisualStyleBackColor = True
        '
        'FPendant
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(811, 537)
        Me.Controls.Add(Me.btnReturnValueFromRobot)
        Me.Controls.Add(Me.btnShowOffsets)
        Me.Controls.Add(Me.btnTray)
        Me.Controls.Add(Me.grpTicTacToeTray)
        Me.Controls.Add(Me.grpTicTacToeGrid)
        Me.Controls.Add(Me.grpShoulder)
        Me.Controls.Add(Me.grpElbow)
        Me.Controls.Add(Me.grpHand)
        Me.Controls.Add(Me.grpTurret)
        Me.Controls.Add(Me.grWristControls)
        Me.Controls.Add(Me.btnAboveBoard)
        Me.Controls.Add(Me.btnGoToSoftHome)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FPendant"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Pendant"
        Me.grWristControls.ResumeLayout(False)
        Me.grpTurret.ResumeLayout(False)
        Me.grpHand.ResumeLayout(False)
        Me.grpElbow.ResumeLayout(False)
        Me.grpShoulder.ResumeLayout(False)
        Me.grpTicTacToeGrid.ResumeLayout(False)
        Me.grpTicTacToeTray.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnGoToSoftHome As System.Windows.Forms.Button
    Friend WithEvents btnAboveBoard As System.Windows.Forms.Button
    Friend WithEvents btnWristLeft As System.Windows.Forms.Button
    Friend WithEvents btnTurretLeft As System.Windows.Forms.Button
    Friend WithEvents btnWristOut As System.Windows.Forms.Button
    Friend WithEvents btnWristRight As System.Windows.Forms.Button
    Friend WithEvents btnWristIn As System.Windows.Forms.Button
    Friend WithEvents grWristControls As System.Windows.Forms.GroupBox
    Friend WithEvents btnTurretRight As System.Windows.Forms.Button
    Friend WithEvents grpTurret As System.Windows.Forms.GroupBox
    Friend WithEvents btnHandOpen As System.Windows.Forms.Button
    Friend WithEvents btnHandClose As System.Windows.Forms.Button
    Friend WithEvents grpHand As System.Windows.Forms.GroupBox
    Friend WithEvents grpElbow As System.Windows.Forms.GroupBox
    Friend WithEvents btnElbowOut As System.Windows.Forms.Button
    Friend WithEvents btnElbowIn As System.Windows.Forms.Button
    Friend WithEvents grpShoulder As System.Windows.Forms.GroupBox
    Friend WithEvents btnShoulderOut As System.Windows.Forms.Button
    Friend WithEvents btnShoulderIn As System.Windows.Forms.Button
    Friend WithEvents grpTicTacToeGrid As System.Windows.Forms.GroupBox
    Friend WithEvents btnPlace2 As System.Windows.Forms.Button
    Friend WithEvents btnPlace3 As System.Windows.Forms.Button
    Friend WithEvents btnPlace4 As System.Windows.Forms.Button
    Friend WithEvents btnPlace5 As System.Windows.Forms.Button
    Friend WithEvents btnPlace6 As System.Windows.Forms.Button
    Friend WithEvents btnPlace7 As System.Windows.Forms.Button
    Friend WithEvents btnPlace8 As System.Windows.Forms.Button
    Friend WithEvents btnPlace9 As System.Windows.Forms.Button
    Friend WithEvents btnPlace1 As System.Windows.Forms.Button
    Friend WithEvents grpTicTacToeTray As System.Windows.Forms.GroupBox
    Friend WithEvents btnO1 As System.Windows.Forms.Button
    Friend WithEvents btnX2 As System.Windows.Forms.Button
    Friend WithEvents btnO2 As System.Windows.Forms.Button
    Friend WithEvents btnX3 As System.Windows.Forms.Button
    Friend WithEvents btnO3 As System.Windows.Forms.Button
    Friend WithEvents btnX5 As System.Windows.Forms.Button
    Friend WithEvents btnO5 As System.Windows.Forms.Button
    Friend WithEvents btnX1 As System.Windows.Forms.Button
    Friend WithEvents btnTray As System.Windows.Forms.Button
    Friend WithEvents btnShowOffsets As System.Windows.Forms.Button
    Friend WithEvents btnX4 As System.Windows.Forms.Button
    Friend WithEvents btnO4 As System.Windows.Forms.Button
    Friend WithEvents btnReturnValueFromRobot As System.Windows.Forms.Button
End Class
