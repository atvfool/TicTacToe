﻿' -------------------------------------------------------------------------
' Class: CTicTacToe
' Author: Andrew Hayden
' Abstract: Tic tac toe module
'
' Revision        Owner   Changes:
' 1  2013/05/30   A.H.    Created.
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------
Option Explicit On

' -------------------------------------------------------------------------
' Imports
' -------------------------------------------------------------------------

Public Class CTicTacToeGame

    ' -------------------------------------------------------------------------
    ' Name: <name>
    ' Abstract: <description>
    ' -------------------------------------------------------------------------

    ' -------------------------------------------------------------------------
    ' Class Properties
    ' -------------------------------------------------------------------------
    ' 0-1-2
    ' 1
    ' 2
    ' First Number is row, second is columns
    Private m_aaintPlayerMoves(2, 2) As Integer ' 0 = Empty, 1 = player, 2 = cpu
    ' Decides if the player or cpu goes first, 1 = player, 2 = CPU
    Private m_intWhoMovesFirst As Integer
    ' Decices what piece the player uses, 1 = X, 2 = 0
    Private m_intPlayerPiece As Integer
    ' 0 = Not Over, 1 = Player, 2 = CPU, 3 = Tie
    Private m_intWhoWon As Integer
    ' 1 = Easy, 2 = Medium, 3 = Hard
	Private m_intDifficulty As Integer = 1



    ' -------------------------------------------------------------------------
    ' Name: New
    ' Abstract: Constructor
    ' -------------------------------------------------------------------------
    Public Sub New()

        Try

            InitializeBoard()

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: InitializeBoard
    ' Abstract: Gets the game ready
    ' -------------------------------------------------------------------------
    Private Sub InitializeBoard()

        Try

            Dim intColumnIndex As Integer = 0
            Dim intRowIndex As Integer = 0

            For intColumnIndex = m_aaintPlayerMoves.GetLowerBound(0) To m_aaintPlayerMoves.GetUpperBound(0)

                For intRowIndex = m_aaintPlayerMoves.GetLowerBound(1) To m_aaintPlayerMoves.GetUpperBound(1)

                    m_aaintPlayerMoves(intColumnIndex, intRowIndex) = 0

                Next

            Next

            m_intWhoWon = 0

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: PlaceMove
    ' Abstract: Places the move if it can otherwise does nothing
    ' -------------------------------------------------------------------------
    Public Function PlaceMove(ByVal intRows As Integer, ByVal intColumns As Integer, ByVal intPlayer As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            If IsGameOver() = False Then

                If CheckMove(intRows, intColumns) = True Then

                    SetPiece(intRows, intColumns, intPlayer)

                    blnResult = True

                End If

            End If

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: CheckMove
    ' Abstract: Check if the move is available, place the piece, and record
    ' -------------------------------------------------------------------------
    Private Function CheckMove(ByVal intRows As Integer, ByVal intColumns As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

			If GetPiece(intRows, intColumns) = 0 Then

				blnResult = True

			End If

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: IsGameOver
    ' Abstract: Checks if either player won or if the move results in a tie
    ' -------------------------------------------------------------------------
    Public Function IsGameOver() As Boolean

        Dim blnResult As Boolean = False

        Try

            Dim intIndex As Integer = 0
            Dim blnCheckIfPlayerWon As Boolean = False


            For intIndex = 1 To 2 Step 1

                blnCheckIfPlayerWon = False

                blnCheckIfPlayerWon = CheckIfAPlayerWon(intIndex)

                If blnCheckIfPlayerWon = True Then

                    m_intWhoWon = intIndex
                    blnResult = True

                End If

            Next

            If blnResult = False And AreThereAnyMovesLeft() = False Then

                m_intWhoWon = 3
                blnResult = True

            End If

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: CheckIfAPlayerWon
    ' Abstract: Checks if one of the players won, if yes then return true
    ' -------------------------------------------------------------------------
    Private Function CheckIfAPlayerWon(ByVal intPlayerType As Integer) As Boolean

        Dim blnResult As Boolean = False

        Try

            ' Check all the rows
            If GetPiece(0, 0) = intPlayerType And _
               GetPiece(0, 1) = intPlayerType And _
               GetPiece(0, 2) = intPlayerType Then

                blnResult = True

            ElseIf GetPiece(1, 0) = intPlayerType And _
                   GetPiece(1, 1) = intPlayerType And _
                   GetPiece(1, 2) = intPlayerType Then

                blnResult = True

            ElseIf GetPiece(2, 0) = intPlayerType And _
                   GetPiece(2, 1) = intPlayerType And _
                   GetPiece(2, 2) = intPlayerType Then

                blnResult = True

                ' Check all the columns
            ElseIf GetPiece(0, 0) = intPlayerType And _
                   GetPiece(1, 0) = intPlayerType And _
                   GetPiece(1, 0) = intPlayerType Then

                blnResult = True

            ElseIf GetPiece(0, 1) = intPlayerType And _
                   GetPiece(1, 1) = intPlayerType And _
                   GetPiece(2, 1) = intPlayerType Then

                blnResult = True

            ElseIf GetPiece(0, 2) = intPlayerType And _
                   GetPiece(1, 2) = intPlayerType And _
                   GetPiece(2, 2) = intPlayerType Then

                blnResult = True

                ' Diagonal
            ElseIf GetPiece(0, 0) = intPlayerType And _
                   GetPiece(1, 1) = intPlayerType And _
                   GetPiece(2, 2) = intPlayerType Then

                blnResult = True

            ElseIf GetPiece(0, 2) = intPlayerType And _
                   GetPiece(1, 1) = intPlayerType And _
                   GetPiece(2, 0) = intPlayerType Then

                blnResult = True

            End If

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

        Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: AreThereAnyMovesLeft
    ' Abstract: Checks if there are any moves left, If yes returns true
    ' -------------------------------------------------------------------------
    Private Function AreThereAnyMovesLeft() As Boolean

        Dim blnResult As Boolean = False

        Try

            '  Are there any moves still left?
            If GetPiece(0, 0) = 0 Or _
                   GetPiece(0, 1) = 0 Or _
                   GetPiece(0, 2) = 0 Or _
                   GetPiece(1, 0) = 0 Or _
                   GetPiece(1, 1) = 0 Or _
                   GetPiece(1, 2) = 0 Or _
                   GetPiece(2, 0) = 0 Or _
                   GetPiece(2, 1) = 0 Or _
                   GetPiece(2, 2) = 0 Then
                ' Yes, The Game Can Continue
                blnResult = True
            End If


        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

		Return blnResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: ComputerPlaceMove
    ' Abstract: Will place a move for the computer
    ' -------------------------------------------------------------------------
	Public Function ComputerPlaceMove() As Integer()

		Dim intComputerMove(2) As Integer

		Try

			Select Case m_intDifficulty
				Case 1

					intComputerMove = EasyMove()

				Case 2
					' Medium
				Case 3
					' Hard
			End Select

		Catch excError As Exception

			WriteLog(excError.ToString)

		End Try

		Return intComputerMove

	End Function



    ' -------------------------------------------------------------------------
    ' Name: EasyMove
    ' Abstract: Will place a move for the computer
    ' -------------------------------------------------------------------------
	Private Function EasyMove() As Integer()

		Dim intComputerMove(2) As Integer

		Try

			Dim rndNumber As Random
			rndNumber = New Random
			Dim intRow As Integer
			Dim intColumn As Integer

			Do

				intRow = rndNumber.Next(0, 3)
				intColumn = rndNumber.Next(0, 3)

			Loop Until PlaceMove(intRow, intColumn, 2) = True

			intComputerMove(0) = intRow
			intComputerMove(1) = intColumn

		Catch excError As Exception

			WriteLog(excError.ToString)

		End Try

		Return intComputerMove

	End Function




#Region "Get / Set Methods"



    ' -------------------------------------------------------------------------
    ' Name: GetPiece
    ' Abstract: Returns the piece
    ' -------------------------------------------------------------------------
    Public Function GetPiece(ByVal intRow As Integer, ByVal intColumn As Integer) As Integer

        Dim intResult As Integer = 0

        Try

            If intRow > 2 Then intRow = 2
            If intRow < 0 Then intRow = 0
            If intColumn > 2 Then intColumn = 2
            If intColumn < 0 Then intColumn = 0

            intResult = m_aaintPlayerMoves(intRow, intColumn)

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

        Return intResult

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetPiece
    ' Abstract: Sets the piece
    ' -------------------------------------------------------------------------
    Public Sub SetPiece(ByVal intRow As Integer, ByVal intColumn As Integer, ByVal intPlayer As Integer)

        Try

            If intRow > 2 Then intRow = 2
            If intRow < 0 Then intRow = 0
            If intColumn > 2 Then intColumn = 2
            If intColumn < 0 Then intColumn = 0
            If intPlayer < 0 Then intPlayer = 0
            If intPlayer > 2 Then intPlayer = 2

            m_aaintPlayerMoves(intRow, intColumn) = intPlayer

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: GetBoard
    ' Abstract: Returns the board
    ' -------------------------------------------------------------------------
    Public Function GetBoard() As Integer(,)

        Return m_aaintPlayerMoves

    End Function



    ' -------------------------------------------------------------------------
    ' Name: SetBoard
    ' Abstract: sets the board
    ' -------------------------------------------------------------------------
    Public Sub SetBoard(ByVal aaintNewBoard(,) As Integer)

        Try

            m_aaintPlayerMoves = aaintNewBoard

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: SetWinner
    ' Abstract: Sets The Winner
    ' -------------------------------------------------------------------------
    Public Sub SetWinner(ByVal intWinner As Integer)

        Try

            If intWinner < 0 Then intWinner = 0
            If intWinner > 3 Then intWinner = 3

            m_intWhoWon = intWinner

        Catch excError As Exception

            WriteLog(excError.ToString)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: GetWinner
    ' Abstract: Returns the Winner
    ' -------------------------------------------------------------------------
    Public Function GetWinner() As Integer

        Return m_intWhoWon

    End Function

#End Region

End Class
